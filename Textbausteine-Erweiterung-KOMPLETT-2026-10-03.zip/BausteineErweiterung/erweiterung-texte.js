// Datei: erweiterung-texte.js
// Projekt: Textbausteine — Teil: Chrome-Erweiterung
// Zweck: Alle sichtbaren Texte der Erweiterung, nach dem Vorbild von
//        texte.js der App. Die App-Texte (texte.js) reisen unverändert
//        mit; hier stehen NUR die Texte, die es in der App nicht gibt:
//        das Symbol-Fenster, die Einblendungen in der Seite und die
//        kleinen Meldungen. Deutsch, keine Programmierer-Begriffe.

"use strict";
window.TB = window.TB || {};

TB.TE = {

  // ---- Symbol-Fenster (Popup) ---------------------------------------
  weltDev: "Testwelt (Dev)",
  weltProd: "Normale Welt",
  nichtAngemeldet: "Noch nicht angemeldet.",
  angemeldetAls: "Angemeldet als ",
  anzahlBausteine: "Bausteine an Bord: ",
  zuletztGeholt: "Zuletzt geholt: ",
  nieGeholt: "noch nie",
  fassung: "Fassung: ",
  mail: "E-Mail",
  passwort: "Passwort",
  anmelden: "Anmelden",
  abmelden: "Abmelden",
  jetztHolen: "Jetzt holen",
  holtGerade: "Holt …",
  uebungsfeldOeffnen: "Übungsfeld öffnen",
  seiteEinschalten: "Auf dieser Seite einschalten",
  seiteEntfernen: "Von dieser Seite entfernen",
  seitenTitel: "Eingeschaltete Seiten",
  keineSeiten: "Noch keine. Die Kürzel wirken nur auf Seiten, die Du hier einschaltest — und immer im Übungsfeld.",
  seiteEingeschaltet: "Eingeschaltet. Die Seite einmal neu laden, dann wirken die Kürzel dort.",
  seiteAbgelehnt: "Chrome hat die Erlaubnis nicht erteilt — nichts geändert.",
  seiteUnpassend: "Auf dieser Art von Seite kann die Erweiterung nicht wirken (z. B. Chrome-eigene Seiten).",
  anmeldungFehlt: "Bitte E-Mail und Passwort eintragen.",
  faecherLeeren: "Fächer leeren",
  anmeldungMerken: "Anmeldung merken — meldet sich nach Ablauf selbst neu an (gespeichert nur auf diesem Gerät)",
  faecherGeleert: "Alle Fächer sind geleert.",

  // ---- Meldungen in der Seite (Toast) --------------------------------
  unbekanntesKuerzel: "Kein Baustein mit dem Kürzel „;;%s“.",
  inZwischenablage: "Einfügen ging hier nicht — der Baustein liegt in der Zwischenablage: mit Strg+V einsetzen.",
  bausteinFehler: "Der Baustein meldet: ",

  // ---- Lücken-Fenster --------------------------------------------------
  lueckenEinfuegen: "Einfügen",
  abbrechen: "Abbrechen (Esc)",
  vorschau: "Vorschau",

  // ---- Such-Fenster (;;?) ----------------------------------------------
  sucheTitel: "Baustein suchen",
  sucheHinweis: "Tippen zum Filtern (auch im Text) · Pfeiltasten wählen · Eingabetaste fügt ein · Esc schliesst",
  sucheLeer: "Kein Baustein passt.",

  // ---- Auswahl-Fenster beim Tippen ---------------------------------------
  wahlHaeufigste: "——  Häufigste  ——",
  wahlAlphabetisch: "——  Alphabetisch  ——",
  wahlHinweis: "Klick fügt ein · Esc schliesst · Weitertippen verfeinert",

  // ---- Fächer (Zwischenspeicher) ------------------------------------------
  faecherKopf: "Zwischenspeicher — Klick setzt ein",
  faecherMerkenKopf: "Zwischenspeicher — Klick merkt die Zwischenablage",
  fachGemerkt: "Gemerkt in Fach ",
  fachEingesetzt: "Eingesetzt aus Fach ",
  fachLeer: "Dieses Fach ist leer oder abgelaufen (Fächer leeren sich nach 12 Stunden von selbst).",
  fachLeerZeile: "(leer)",
  fachNichtsKopiert: "Die Zwischenablage ist leer. Zuerst mit Strg+C kopieren, dann das Kürzel tippen.",
  fachLesenVerwehrt: "Chrome lässt das Lesen der Zwischenablage hier nicht zu — die Erweiterung einmal entfernen und neu laden, dann fragt Chrome nach der Erlaubnis.",

  // ---- Standort (Etappe 6) --------------------------------------------------
  standortTitel: "Standort dieses Geräts",
  standortKeiner: "(kein Standort)",
  standortHinweis: "Bausteine mit Standort-Fassungen liefern hier die passende Fassung. Gilt nur in diesem Browser.",

  // ---- Entwurf (;;neu) ------------------------------------------------------
  entwurfTitel: "Als Entwurf sichern",
  entwurfWarnung: "Das liegt in der Zwischenablage und wird als Entwurf in Deine Bausteine gelegt. KONTROLLIERE: kein Patientenname, keine Patientendaten!",
  entwurfSichern: "Als Entwurf sichern",
  entwurfGesichert: "Als Entwurf gesichert — am nächsten Gerät unter Entwürfe.",
  entwurfLeer: "Die Zwischenablage ist leer. Zuerst Text markieren und Strg+C drücken, dann ;;neu tippen.",
  entwurfFehler: "Der Entwurf konnte nicht hochgeladen werden: ",

  // ---- Masken (Etappe 8) ----------------------------------------------------
  weiter: "Weiter",
  maskeKategorie: "Aus der Kategorie „%s“ einfügen:",
  maskeKategorieLeer: "Noch kein Baustein mit dieser Kategorie — der Abschnitt bleibt leer, und Du diktierst später direkt ins Zielfeld.",
  stelleVerloren: "Die Einfügestelle ging verloren — bitte nochmals ins Feld klicken und das Kürzel neu tippen.",
  startFehler: "Baustein konnte nicht gestartet werden",

  // ---- MRI-Anmeldung Praxis (30.9.) -----------------------------------
  mriKnopf: "MRI-Anmeldung",
  mriTitel: "MRI-Anmeldung",
  mriHinweis: "In Axenita das ausgefüllte Anmelde-Formular markieren (Strg+A) und kopieren (Strg+C) — die Kopie unten wird automatisch gelesen. Erkannt werden Medizinisch Radiologisches Institut, RNR, Hirslanden und RIMED. Alles lässt sich von Hand korrigieren.",
  mriLaden: "Zwischenablage neu einlesen",
  mriAnrede: "Anrede",
  mriHerr: "Herr",
  mriFrau: "Frau",
  mriInstitut: "Empfänger",
  mriInstitutWahl: "(Empfänger wählen)",
  mriName: "Nachname",
  mriGeb: "Geb.-Datum",
  mriOeffnen: "E-Mail in Outlook öffnen",
  mriErkannt: "Erkannt: %s",
  mriKeinKreuz: "Kein angekreuzter Standort (☒) gefunden — bitte den Standort im Aufklappmenü wählen.",
  mriUnbekannt: "Formular nicht erkannt — alle Empfänger stehen zur Wahl. Bitte melde mir das (Kopie aus dem grossen Feld), dann bringe ich der Maske dieses Formular bei.",
  mriKeinEmpfaenger: "Bitte zuerst den Empfänger im Aufklappmenü wählen.",
  mriAnredeFehlt: "Bitte zuerst Herr oder Frau wählen.",
  mriFormularSagt: "Laut Formular: %s",
  mriAnredeWiderspruch: "Achtung: Deine Wahl passt nicht zur Geschlechtsangabe im Formular (%s) — bitte prüfen.",
  mriNameFehlt: "Bitte den Nachnamen eintragen.",
  mriZwischenablageLeer: "Die Zwischenablage liess sich nicht lesen — bitte die Formular-Kopie mit Strg+V ins grosse Feld einfügen.",
  mriGeoeffnet: "Outlook öffnet die fertige Mail samt Signatur. Das PDF (aus Axenita → E-Mail Versand) noch hineinziehen — gesendet wird von Hand.",

  // ---- Patienten-Kette (;;pat, 30.9.) ---------------------------------
  patFertig: "In der Zwischenablage: %s — in der Patientenliste mit Strg+V einsetzen.",
  patNichtErkannt: "Keine Patientenangaben erkannt. Zuerst in Axenita die Patienteninformation markieren und mit Strg+C kopieren, dann ;;pat tippen.",
  patNurAnzeige: "Die Kette konnte nicht in die Zwischenablage gelegt werden — bitte von Hand übernehmen: %s",

  // ---- EEG-Werk (Etappe 10) -------------------------------------------
  eegTitel: "EEG-Werk",
  eegKeinKatalog: "EEG-Katalog noch nicht da: in der App einmal den Bereich EEG öffnen (Grundausstattung), dann hier eine Minute auf den Abgleich warten.",
  eegEinfuegen: "Einfügen",
  eegKopieren: "Befund+Beurteilung kopieren",
  eegIndKopieren: "Indikation kopieren",
  eegAnamKopieren: "Anamnese kopieren",
  eegIndikation: "Indikation",
  eegAnamnese: "Relevante Anamnese",
  eegBefundTitel: "Befund",
  eegBeurteilungTitel: "Beurteilung",
  eegIpsSpaeter: ";;eegips ist noch nicht fertig definiert und kommt in einer späteren Etappe — vorerst gibt es ;;eeg.",
  eegMediTitel: "Antikonvulsiva (Dosis in mg — «mg» hängt die Ausgabe selbst an)",
  eegMediDosis: "Dosis",
  eegMediFrei: "oder frei …",
  eegMediMehr: "+ Medikament",
  eegAbleitung: "Ableitung:",
  eegVigilanz: "Vigilanz:",
  eegArtefakte: "Artefakte:",
  eegArtAugen: "Augen",
  eegArtMuskel: "Muskel",
  eegArtBewegung: "Bewegung",
  eegZeilenTitel: "Herde, steile Transienten und Entladungen (Häkchen = Zeile zählt; jede Änderung setzt es von selbst)",
  eegHerdWort: "Herd",
  eegTransKurz: "Transienten",
  eegEntWort: "Entladung",
  eegMehrHerd: "+ Herd-Zeile",
  eegMehrTrans: "+ Transienten-Zeile",
  eegMehrEnt: "+ Entladungs-Zeile",
  eegAutoTitel: "Kern-Beurteilung (baut sich aus dem Befund — der Stift überschreibt)",
  eegZeileAktiv: "Zeile zählt im Befund",
  statusTitel: "Status",
  statusKeineDaten: "Status-Daten noch nicht da: in der App einmal den Bereich Status öffnen, dann kurz auf den Abgleich warten.",
  statusDazu: "Untersuchung dazu …",
  statusMuskeln: "Muskeln",
  statusEinfuegen: "Einfügen",
  statusKopieren: "Als Text kopieren",
  eegDazu: "Punkt dazu …",
  eegUeberschreiben: "Satz überschreiben",
  eegZurueckVorgabe: "Auf Vorgabe zurück"
};
