// Datei: mri-anmeldung.js
// Projekt: Textbausteine — Teil: Chrome-Erweiterung
// Zweck: Die MRI-Anmeldung an der Praxis (30.9.), ganz ohne Skript:
//        Näd kopiert das ausgefüllte Axenita-Anmeldeformular (Strg+A,
//        Strg+C) und ruft die Maske auf — mit ;;mri in einem Feld auf
//        einer eingeschalteten Seite ODER über den Knopf im
//        Symbol-Fenster. Die Maske erkennt vier Formulare:
//        Medizinisch Radiologisches Institut (5 Standorte, ☒ entscheidet),
//        RNR (eine Adresse), Hirslanden (☒-Standort entscheidet zwischen
//        Klinik Hirslanden/Seefeld und Klinik Im Park) und RIMED (das
//        Formular nennt keinen Standort — Vorgabe Altstetten). Das Menü
//        zeigt nur die Adressen des erkannten Formulars. Dazu Nachname,
//        Geburtsdatum und, wo das Formular es sagt, das Geschlecht als
//        Kontroll-Hinweis. Herr/Frau ist NIE vorgewählt: Ohne Wahl lässt
//        sich keine Mail öffnen (Wunsch 30.9., gegen Verwechslungen).
//        Der Knopf öffnet eine NEUE, fertig adressierte Outlook-Mail
//        mit Text UND Signatur (Outlook hängt sie auf diesem Weg nicht
//        selbst an). Das PDF zieht Näd hinein; GESENDET WIRD VON HAND.
//        GRUNDSATZ: Nichts davon wird gespeichert oder ins Netz
//        geschickt — die Angaben wandern nur in die eine Mail.

"use strict";
window.TB = window.TB || {};

// ---- Reine Helfer (auch im Prüflauf ohne Browser testbar) --------------
TB.mriRein = (function () {

  // Alle Empfänger. Die Nummer im Aufklappmenü ist die Stelle hier + 1.
  // anbieter gruppiert das Menü und steuert die Erkennung.
  var EMPFAENGER = [
    { anbieter: "mri", gruppe: "Medizinisch Radiologisches Institut", name: "MRI IR Bahnhof Oerlikon", mail: "ir-bho@mri-roentgen.ch" },
    { anbieter: "mri", gruppe: "Medizinisch Radiologisches Institut", name: "MRI Bahnhofsplatz",       mail: "a-bhp@mri-roentgen.ch" },
    { anbieter: "mri", gruppe: "Medizinisch Radiologisches Institut", name: "MRI Bahnhof Oerlikon",    mail: "a-bho@mri-roentgen.ch" },
    { anbieter: "mri", gruppe: "Medizinisch Radiologisches Institut", name: "MRI Stadelhofen",         mail: "a-sth@mri-roentgen.ch" },
    { anbieter: "mri", gruppe: "Medizinisch Radiologisches Institut", name: "MRI Schulthess Klinik",   mail: "a-shk@mri-roentgen.ch" },
    { anbieter: "rnr", gruppe: "RNR", name: "RNR (Wallisellen / Stettbach)", mail: "info@rnr.ch" },
    { anbieter: "hirslanden", gruppe: "Hirslanden", name: "Hirslanden — Klinik Hirslanden / Ärztezentrum Seefeld", mail: "radiologieanmeldung.hirslanden@hirslanden.ch" },
    { anbieter: "hirslanden", gruppe: "Hirslanden", name: "Hirslanden — Klinik Im Park", mail: "radiologieanmeldung.impark@hirslanden.ch" },
    { anbieter: "rimed", gruppe: "RIMED", name: "RIMED Altstetten", mail: "altstetten@rimed.ch" },
    { anbieter: "rimed", gruppe: "RIMED", name: "RIMED Bellevue",   mail: "bellevue@rimed.ch" },
    { anbieter: "rimed", gruppe: "RIMED", name: "RIMED Oerlikon",   mail: "oerlikon@rimed.ch" },
    { anbieter: "rimed", gruppe: "RIMED", name: "RIMED Sihlcity",   mail: "sihlcity@rimed.ch" }
  ];
  var ANBIETER_NAME = { mri: "Medizinisch Radiologisches Institut", rnr: "RNR",
    hirslanden: "Hirslanden", rimed: "RIMED" };
  var KREUZ = "\u2612"; // ☒

  var SIGNATUR = "Dr. med. Nadir Tissira\r\nFMH Neurologie\r\n\r\n" +
    "Praxis Neuromed\r\nStampfenbachstrasse 63\r\n8006 Zürich\r\n\r\n" +
    "Tel:  044 363 64 22\r\n";

  function nummerVon(mail) {
    for (var i = 0; i < EMPFAENGER.length; i++) {
      if (EMPFAENGER[i].mail === mail) return i + 1;
    }
    return 0;
  }

  // Welches Formular ist es? Reihenfolge zählt: Hirslanden zuerst
  // (sein Text nennt „MRI OFFENES GERÄT"), dann RNR, RIMED, zuletzt
  // das Medizinisch Radiologische Institut.
  // Axenita/ONLYOFFICE kopiert teils geschützte oder schmale Leerzeichen
  // und andere Kästchen-Zeichen — alles auf Normalform bringen.
  function normal(text) {
    return String(text || "")
      .replace(/[\u00a0\u2007\u202f\u2002\u2003\u2009]/g, " ")
      .replace(/[\u2611\u22a0\u2718\u2716]/g, KREUZ)
      .replace(/ {2,}/g, " ");
  }

  // Welches Formular ist es? Kopf- und Fusszeilen (dort stehen oft
  // Standorte und Mailadressen) kommen beim Kopieren nicht immer mit —
  // darum zählen auch Merkmale aus dem Formular-Rumpf.
  function anbieterVon(text) {
    var t = normal(text);
    if (/hirslanden/i.test(t) || /Klinik Im Park/i.test(t) ||
        /PATIENTEN-INFORMATIONEN/.test(t) || /MRI OFFENES GER/i.test(t) ||
        /BEFUNDKOPIE AN/.test(t)) return "hirslanden";
    if ((/Wallisellen/i.test(t) && /Stettbach/i.test(t)) || /\brnr\b/i.test(t) ||
        /Praxis-Standort Wunsch/i.test(t)) return "rnr";
    if (/Upright\s*\/\s*offenes MRI/i.test(t) || /VueMotion/i.test(t) || /rimed/i.test(t)) return "rimed";
    if (/mri-roentgen/i.test(t) || /Medizinisch Radiologisch/i.test(t) ||
        /Bitte Voruntersuchungen mitbringen/i.test(t) || /SZINTI/i.test(t)) return "mri";
    var zeilen = t.split(/\r\n?|\n/);
    for (var i = 0; i < zeilen.length; i++) {
      var z = zeilen[i].trim();
      for (var k = 0; k < 5; k++) {
        if (z.indexOf(EMPFAENGER[k].name) !== -1) return "mri";
      }
    }
    return "";
  }

  // Medizinisch Radiologisches Institut: die Zeile, die mit einem
  // Institutsnamen beginnt UND ein ☒ trägt.
  function mriStandort(text) {
    var zeilen = normal(text).split(/\r\n?|\n/);
    for (var i = 0; i < zeilen.length; i++) {
      var z = zeilen[i].trim();
      if (z.indexOf(KREUZ) === -1) continue;
      // „MRI IR Bahnhof Oerlikon" steht an erster Stelle der Liste und
      // enthält „MRI Bahnhof Oerlikon" NICHT — die Reihenfolge ist sicher.
      for (var k = 0; k < 5; k++) {
        if (z.indexOf(EMPFAENGER[k].name) !== -1) return k + 1;
      }
    }
    return 0;
  }

  // Hirslanden: Im Kopf des Formulars steht vor jedem Standort ein
  // Kästchen. Nur der Kopf bis „PATIENTEN-INFORMATIONEN" zählt — weiter
  // unten nennen die Radiologen-Kästchen „Klinik Im Park" nochmals.
  function hirslandenStandort(text) {
    var t = normal(text);
    var bis = t.search(/PATIENTEN-INFORMATIONEN/i);
    var kopf = bis === -1 ? t.slice(0, 1500) : t.slice(0, bis);
    var stuecke = kopf.split(/([\u2610\u2612])/);
    for (var i = 1; i < stuecke.length - 1; i += 2) {
      if (stuecke[i] !== KREUZ) continue;
      var danach = stuecke[i + 1];
      if (/Im\s+Park/i.test(danach)) return nummerVon("radiologieanmeldung.impark@hirslanden.ch");
      if (/Klinik\s+Hirslanden|Seefeld/i.test(danach)) return nummerVon("radiologieanmeldung.hirslanden@hirslanden.ch");
    }
    return 0;
  }

  // Die Zelle direkt HINTER einer Beschriftung (Word-Tabellen kommen
  // beim Kopieren mit Tab zwischen den Zellen). Die ERSTE Beschriftung
  // entscheidet — ist ihre Zelle leer, bleibt das Feld leer, statt
  // weiter unten z. B. den Namen des zuweisenden Arztes zu erwischen.
  var BESCHRIFTUNG = {
    name: /^Name:?$/i,
    geb: /^(Geb\.?[\s-]*(Datum|Dat\.?)|Geburtsdatum):?$/i,
    geschlecht: /^Geschl(\.|echt)?:?$/i
  };

  function zerlege(text) {
    var e = { anbieter: "", empfaenger: 0, nachname: "", geb: "", geschlecht: "" };
    var gesehen = { name: false, geb: false, geschlecht: false };
    normal(text).replace(/\r\n?/g, "\n").split("\n").forEach(function (zeile) {
      var zellen = zeile.split("\t").map(function (z) { return z.trim(); });
      zellen.forEach(function (zelle, j) {
        var wert = zellen[j + 1] || "";
        if (!gesehen.name && BESCHRIFTUNG.name.test(zelle)) {
          gesehen.name = true;
          if (wert && wert.toLowerCase() !== "name") e.nachname = wert;
        } else if (!gesehen.name) {
          var m1 = /^Name\s*:\s*(\S.*)$/i.exec(zelle);
          if (m1) { gesehen.name = true; e.nachname = m1[1].trim(); }
        }
        if (!gesehen.geb && BESCHRIFTUNG.geb.test(zelle)) {
          gesehen.geb = true;
          var d = /([0-3]?\d\.[01]?\d\.\d{2,4})/.exec(wert);
          if (d) e.geb = d[1];
        } else if (!gesehen.geb) {
          var m2 = /^(?:Geb\.?[\s-]*(?:Datum|Dat\.?)|Geburtsdatum)\s*:\s*([0-3]?\d\.[01]?\d\.\d{2,4})/i.exec(zelle);
          if (m2) { gesehen.geb = true; e.geb = m2[1]; }
        }
        if (!gesehen.geschlecht && BESCHRIFTUNG.geschlecht.test(zelle)) {
          gesehen.geschlecht = true;
          if (/weiblich/i.test(wert)) e.geschlecht = "Frau";
          else if (/männlich|maennlich/i.test(wert)) e.geschlecht = "Herr";
        }
      });
    });
    e.anbieter = anbieterVon(text);
    if (e.anbieter === "mri") e.empfaenger = mriStandort(text);
    else if (e.anbieter === "rnr") e.empfaenger = nummerVon("info@rnr.ch");
    else if (e.anbieter === "hirslanden") {
      // Im Park nur, wenn angekreuzt; sonst Klinik Hirslanden (Näd 30.9.).
      e.empfaenger = hirslandenStandort(text) ||
        nummerVon("radiologieanmeldung.hirslanden@hirslanden.ch");
    }
    // RIMED: das Formular nennt keinen Standort — Vorgabe Altstetten.
    else if (e.anbieter === "rimed") e.empfaenger = nummerVon("altstetten@rimed.ch");
    e.institut = e.empfaenger; // alter Name, damit ältere Prüfläufe passen
    return e;
  }

  function betreff(anredeKurz, nachname, geb) {
    var b = "MRI-Anmeldung " + anredeKurz + " " + String(nachname || "").trim();
    if (String(geb || "").trim()) b += ", geb. " + String(geb).trim();
    return b;
  }

  function rumpf(anredeWort, nachname) {
    return "Sehr geehrte Damen und Herren\r\n\r\n" +
      "Gerne möchte ich " + anredeWort + " " + String(nachname || "").trim() +
      " zum MRI anmelden.\r\n\r\n" +
      "Freundliche Grüsse\r\n\r\n" + SIGNATUR;
  }

  function mailAdresse(nr) {
    var x = EMPFAENGER[nr - 1];
    return x ? x.mail : "";
  }

  function mailtoUrl(mail, betreffText, rumpfText) {
    return "mailto:" + mail +
      "?subject=" + encodeURIComponent(betreffText) +
      "&body=" + encodeURIComponent(rumpfText);
  }

  return { normal: normal, EMPFAENGER: EMPFAENGER, INSTITUTE: EMPFAENGER, ANBIETER_NAME: ANBIETER_NAME,
           KREUZ: KREUZ, SIGNATUR: SIGNATUR, zerlege: zerlege, anbieterVon: anbieterVon,
           betreff: betreff, rumpf: rumpf, mailAdresse: mailAdresse,
           mailtoUrl: mailtoUrl, nummerVon: nummerVon };
})();

// ---- Ab hier braucht es eine Seite -------------------------------------
if (typeof document !== "undefined") (function () {

  var R = TB.mriRein;

  function zwischenablageText() {
    try {
      return navigator.clipboard.readText()
        .then(function (t) { return String(t || ""); })
        .catch(function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }

  function oeffne(doc, einstellungen) {
    var e = einstellungen || {};

    var alt = doc.querySelector(".tbx-decke[data-tb-mri]");
    if (alt) alt.parentNode.removeChild(alt);

    var decke = doc.createElement("div");
    decke.className = "tbx-decke";
    decke.setAttribute("data-tb-mri", "1");
    var karte = doc.createElement("div");
    karte.className = "tbx-karte tbx-maske";
    decke.appendChild(karte);

    function el(art, klasse, text, wohin) {
      var k = doc.createElement(art);
      if (klasse) k.className = klasse;
      if (text) k.textContent = text;
      (wohin || karte).appendChild(k);
      return k;
    }

    el("div", "tbx-titel", TB.TE.mriTitel);
    el("div", "tbx-klein", TB.TE.mriHinweis);

    var quelle = el("textarea", "tbx-feld tbx-maske-text");
    quelle.rows = 6;
    quelle.style.width = "100%";
    quelle.style.marginTop = "8px";

    var kLaden = el("button", "tbx-knopf", TB.TE.mriLaden);
    kLaden.style.marginTop = "6px";

    var erkannt = el("div", "tbx-erkannt", "");

    // ---- Anrede: zwei grosse Knöpfe, NICHTS vorgewählt ---------------
    var anrede = ""; // "Herr" | "Frau" | ""
    var formularGeschlecht = "";
    var zAnrede = el("div", "tbx-zeile");
    el("div", "tbx-beschriftung", TB.TE.mriAnrede, zAnrede);
    var anredeBox = el("div", "tbx-anrede", "", zAnrede);
    var kHerr = el("button", "tbx-anrede-knopf", TB.TE.mriHerr, anredeBox);
    var kFrau = el("button", "tbx-anrede-knopf", TB.TE.mriFrau, anredeBox);
    kHerr.type = "button"; kFrau.type = "button";
    var formularHinweis = el("div", "tbx-klein", "");

    var zInstitut = el("div", "tbx-zeile");
    el("div", "tbx-beschriftung", TB.TE.mriInstitut, zInstitut);
    var wahlInst = doc.createElement("select");
    wahlInst.className = "tbx-feld";
    // Das Menü zeigt nur, was zum erkannten Formular passt (Näd 30.9.:
    // „die Auswahl immer einschränken auf die, die möglich sind"). Nur
    // ein unbekanntes Formular zeigt alle Empfänger.
    function fuelleMenue(anbieter, vorwahl) {
      wahlInst.textContent = "";
      if (!vorwahl) {
        var leer = doc.createElement("option");
        leer.value = "0"; leer.textContent = TB.TE.mriInstitutWahl;
        wahlInst.appendChild(leer);
      }
      var gruppen = {};
      R.EMPFAENGER.forEach(function (x, i) {
        if (anbieter && x.anbieter !== anbieter) return;
        var ziel = wahlInst;
        if (!anbieter) {
          if (!gruppen[x.gruppe]) {
            gruppen[x.gruppe] = doc.createElement("optgroup");
            gruppen[x.gruppe].label = x.gruppe;
            wahlInst.appendChild(gruppen[x.gruppe]);
          }
          ziel = gruppen[x.gruppe];
        }
        var o = doc.createElement("option");
        o.value = String(i + 1); o.textContent = x.name + "  (" + x.mail + ")";
        ziel.appendChild(o);
      });
      wahlInst.value = String(vorwahl || 0);
    }
    fuelleMenue("", 0);
    zInstitut.appendChild(wahlInst);

    var zName = el("div", "tbx-zeile");
    el("div", "tbx-beschriftung", TB.TE.mriName, zName);
    var fName = doc.createElement("input");
    fName.className = "tbx-feld"; fName.type = "text";
    zName.appendChild(fName);

    var zGeb = el("div", "tbx-zeile");
    el("div", "tbx-beschriftung", TB.TE.mriGeb, zGeb);
    var fGeb = doc.createElement("input");
    fGeb.className = "tbx-feld"; fGeb.type = "text";
    zGeb.appendChild(fGeb);

    var hinweis = el("div", "tbx-warn", "");
    hinweis.style.minHeight = "1.2em";
    var fussHinweis = el("div", "tbx-klein", "");

    var leiste = el("div", "tbx-leiste");
    var kZu = el("button", "tbx-knopf", TB.TE.abbrechen, leiste);
    var kOeffnen = el("button", "tbx-knopf tbx-haupt", TB.TE.mriOeffnen, leiste);

    // Knopf-Zustand und Kontroll-Hinweis zur Anrede nachführen.
    function anredeZeichnen() {
      kHerr.className = "tbx-anrede-knopf" + (anrede === "Herr" ? " tbx-gewaehlt" : "");
      kFrau.className = "tbx-anrede-knopf" + (anrede === "Frau" ? " tbx-gewaehlt" : "");
      kHerr.textContent = (anrede === "Herr" ? "\u2713 " : "") + TB.TE.mriHerr;
      kFrau.textContent = (anrede === "Frau" ? "\u2713 " : "") + TB.TE.mriFrau;
      anredeBox.className = "tbx-anrede";
      kOeffnen.disabled = !anrede;
      kOeffnen.title = anrede ? "" : TB.TE.mriAnredeFehlt;
      var wort = formularGeschlecht === "Frau" ? "weiblich"
        : formularGeschlecht === "Herr" ? "männlich" : "";
      if (anrede && formularGeschlecht && anrede !== formularGeschlecht) {
        formularHinweis.textContent = TB.TE.mriAnredeWiderspruch.replace("%s", wort);
        formularHinweis.style.color = "#b3261e";
        formularHinweis.style.fontWeight = "bold";
      } else {
        formularHinweis.textContent = wort ? TB.TE.mriFormularSagt.replace("%s", wort) : "";
        formularHinweis.style.color = "";
        formularHinweis.style.fontWeight = "";
      }
    }
    kHerr.addEventListener("click", function () { anrede = "Herr"; hinweis.textContent = ""; anredeZeichnen(); });
    kFrau.addEventListener("click", function () { anrede = "Frau"; hinweis.textContent = ""; anredeZeichnen(); });

    // Jede neue Kopie ist ein neuer Patient: ALLES frisch aus der Kopie,
    // auch Empfänger und Anrede — nichts vom vorherigen bleibt stehen.
    function erkennen() {
      var erg = R.zerlege(quelle.value);
      fuelleMenue(erg.anbieter, erg.empfaenger);
      fName.value = erg.nachname;
      fGeb.value = erg.geb;
      formularGeschlecht = erg.geschlecht;
      anrede = "";
      anredeZeichnen();
      fussHinweis.textContent = "";
      erkannt.textContent = erg.anbieter
        ? TB.TE.mriErkannt.replace("%s", R.ANBIETER_NAME[erg.anbieter]) : "";
      if (!quelle.value.trim()) hinweis.textContent = "";
      else if (!erg.anbieter) hinweis.textContent = TB.TE.mriUnbekannt;
      else if (erg.empfaenger) hinweis.textContent = "";
      else hinweis.textContent = TB.TE.mriKeinKreuz;
    }

    function schliessen() {
      if (decke.parentNode) decke.parentNode.removeChild(decke);
      if (e.eigeneSeite) { try { window.close(); } catch (w) { } }
    }

    quelle.addEventListener("input", erkennen);
    wahlInst.addEventListener("change", function () {
      if (wahlInst.value !== "0") hinweis.textContent = "";
    });
    kLaden.addEventListener("click", function () {
      zwischenablageText().then(function (t) {
        if (t === null) { hinweis.textContent = TB.TE.mriZwischenablageLeer; return; }
        quelle.value = t;
        erkennen();
      });
    });
    kOeffnen.addEventListener("click", function () {
      if (!anrede) { hinweis.textContent = TB.TE.mriAnredeFehlt; return; }
      var nr = parseInt(wahlInst.value, 10) || 0;
      if (!nr) { hinweis.textContent = TB.TE.mriKeinEmpfaenger; return; }
      var name = fName.value.trim();
      if (!name) { hinweis.textContent = TB.TE.mriNameFehlt; return; }
      var herr = anrede === "Herr";
      var url = R.mailtoUrl(R.mailAdresse(nr),
        R.betreff(anrede, name, fGeb.value),
        R.rumpf(herr ? "Herrn" : "Frau", name));
      TB.mri.letzteMail = url; // fürs Nachschauen im Prüflauf
      var a = doc.createElement("a");
      a.href = url;
      doc.body.appendChild(a);
      a.click();
      a.parentNode.removeChild(a);
      hinweis.textContent = "";
      fussHinweis.textContent = TB.TE.mriGeoeffnet;
    });
    kZu.addEventListener("click", schliessen);
    karte.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); schliessen(); }
    });
    decke.addEventListener("mousedown", function (ev) {
      if (ev.target === decke) schliessen();
    });

    anredeZeichnen();
    doc.body.appendChild(decke);

    zwischenablageText().then(function (t) {
      if (t === null || !t.trim()) {
        if (t === null) hinweis.textContent = TB.TE.mriZwischenablageLeer;
        quelle.focus();
        return;
      }
      quelle.value = t;
      erkennen();
      quelle.focus();
    });
  }

  TB.mri = { oeffne: oeffne, letzteMail: "" };
})();
