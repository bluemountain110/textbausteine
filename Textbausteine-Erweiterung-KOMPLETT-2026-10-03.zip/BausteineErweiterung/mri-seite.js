// Datei: mri-seite.js
// Projekt: Textbausteine — Teil: Chrome-Erweiterung
// Zweck: Der eine Handgriff der Seite mri.html: die MRI-Maske sofort
//        öffnen. Eigene Datei, weil Chrome in Erweiterungs-Seiten
//        keine Skript-Zeilen direkt im HTML erlaubt.

"use strict";
TB.mri.oeffne(document, { eigeneSeite: true });
