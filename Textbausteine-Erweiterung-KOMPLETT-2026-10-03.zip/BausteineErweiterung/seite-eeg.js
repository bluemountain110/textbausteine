// Datei: seite-eeg.js
// Projekt: Textbausteine — Teil: Chrome-Erweiterung
// Zweck: Der EEG-Schnell-Befund auf einer Seite (Etappe 11): ;;eeg
//        öffnet das Fenster über der Seite — Indikation, Anamnese
//        (Antikonvulsiva mit Dosis), Befund (Dreiknopf Ableitung/
//        Vigilanz, Artefakte, Herd-, Transienten- und Entladungs-
//        Zeilen) und die Kern-Beurteilung, die sich aus dem Befund
//        baut (der Stift überschreibt jeden Satz). Die ganze Logik
//        liefert eeg.js als byteweise App-Kopie; diese Datei baut nur
//        das Fenster. Einfügen setzt EINEN Block („Befund" und
//        „Beurteilung" unterstrichen); Indikation und Anamnese haben
//        eigene Kopier-Knöpfe, weil Axenita dafür eigene Felder hat.
//        ;;eegips ist noch nicht fertig definiert und kommt in einer
//        späteren Etappe. Esc bricht ab, das Kürzel kommt zurück.
//        GRUNDSATZ: nichts wird gespeichert, keine Patientendaten
//        verlassen die Seite.

"use strict";
window.TB = window.TB || {};

// Die Datenquelle für eeg.js: die abgeglichenen Einstellungen der
// Erweiterung — bei jedem Zugriff frisch, nur lesend.
TB.eegQuelle = {
  einstellung: function (name, vorgabe) {
    var H = TB.seite && TB.seite.maskenHelfer;
    var e = H && H.einstellungen ? H.einstellungen() : {};
    return (e && e[name] !== undefined && e[name] !== null) ? e[name] : vorgabe;
  }
};

TB.seiteEeg = (function () {
  function H() { return TB.seite.maskenHelfer; }
  function TE() { return TB.TE; }
  function R() { return TB.eegGrundlage.REGELN; }

  function starte(ort, kuerzel, urspruenglich) {
    var m = TB.eeg.master();
    if (!m) { H().meldung(TE().eegKeinKatalog, true); return; }
    var v = TB.eeg.vorlageMitKuerzel(kuerzel);
    if (v && v.id === "v_eegips") {
      H().meldung(TE().eegIpsSpaeter, true);
      return;
    }
    var zurueck = H().halteStelle(ort);
    oeffneFenster(m, v, kuerzel, function (erg) {
      var ziel = zurueck();
      var ok;
      if (ziel.art === "feld") { H().schreibeText(ziel, erg.text); ok = true; }
      else { ok = H().schreibeHtml(ziel, erg.html, null); }
      if (!ok) { H().inZwischenablage(erg); }
    }, function () {
      if (urspruenglich) H().schreibeText(zurueck(), urspruenglich);
      else zurueck();
    });
  }

  function neueZeile(art) {
    var r = R();
    if (art === "herde") {
      var h = r.herdVorwahl;
      return { aktiv: false, haeufigkeit: h.haeufigkeit, band: h.band,
               lok: h.lok.slice(), seite: h.seite,
               ausbreitung: h.ausbreitung };
    }
    if (art === "entladungen") {
      var e = r.entVorwahl;
      return { aktiv: false, haeufigkeit: e.haeufigkeit,
               form: r.entFormen[0], lok: e.lok.slice(), seite: e.seite,
               ausbreitung: e.ausbreitung };
    }
    return { aktiv: false, haeufigkeit: r.transHaeufigkeiten[0],
             lok: ["temporal", "", "", ""], seite: "", ausbreitung: "" };
  }

  // ---- Das Fenster ------------------------------------------------------
  function oeffneFenster(m, v, kuerzel, beiFertig, beiAbbruch) {
    var doc = H().obersteTuer();
    var gewaehlt = {}, sichtbar = [], werte = {}, abw = {};
    var autoSoll = {};
    var zeilen = { herde: [], entladungen: [], transienten: [] };
    var medis = [];
    var ablWahl = 0, vigWahl = 0;
    if (v) {
      (v.punkte || []).forEach(function (id) {
        sichtbar.push(id); gewaehlt[id] = true; });
      (v.zusatz || []).forEach(function (id) { sichtbar.push(id); });
      Object.keys(v.werte || {}).forEach(function (pid) {
        werte[pid] = {};
        Object.keys(v.werte[pid]).forEach(function (label) {
          werte[pid][label] = v.werte[pid][label]; });
      });
    }
    var i;
    for (i = 0; i < R().herdeVorbereitet; i++)
      zeilen.herde.push(neueZeile("herde"));
    for (i = 0; i < R().entladungenVorbereitet; i++)
      zeilen.entladungen.push(neueZeile("entladungen"));
    zeilen.transienten.push(neueZeile("transienten"));
    for (i = 0; i < R().medisVorbereitet; i++)
      medis.push({ name: "", dosis: "", frei: "" });

    function zeigePunkt(id) {
      if (sichtbar.indexOf(id) === -1) sichtbar.push(id);
    }
    function setzeAbleitung(nr) {
      ablWahl = nr;
      var k = R().ableitungKnoepfe[nr];
      werte.abl_satz = werte.abl_satz || {};
      Object.keys(k.werte).forEach(function (label) {
        werte.abl_satz[label] = k.werte[label]; });
      gewaehlt.abl_satz = true;
      gewaehlt.art_50hz = !!k.artefakt50;
      if (k.artefakt50) zeigePunkt("art_50hz");
    }
    function setzeVigilanz(nr) {
      vigWahl = nr;
      var k = R().vigilanzKnoepfe[nr];
      var p = TB.eeg.punkt(m, "vig_haupt");
      if (!p) return;
      var s = TB.eeg.zerlege(p.text).find(function (x) {
        return x.art !== "text"; });
      if (!s) return;
      (werte.vig_haupt = werte.vig_haupt || {})[s.label] = k.wert;
      gewaehlt.vig_haupt = true;
    }
    // Links = vorangewählt (Näd 2.10.).
    setzeAbleitung(0);
    setzeVigilanz(0);

    function aktiveZeilen() {
      var z = {};
      ["herde", "entladungen", "transienten"].forEach(function (art) {
        z[art] = zeilen[art].filter(function (x) { return x.aktiv; }); });
      z.medis = medis.filter(function (mz) {
        return (mz.name && mz.name !== "") || mz.frei.trim() !== ""; });
      return z;
    }
    function flt() {
      return TB.eeg.fliesstext(m, gewaehlt, werte, abw, aktiveZeilen());
    }

    var decke = doc.createElement("div");
    decke.className = "tbx-decke";
    decke.setAttribute("data-tb-eeg", "");
    var karte = doc.createElement("div");
    karte.className = "tbx-karte tbx-maske tbx-eeg-karte";
    decke.appendChild(karte);

    function zu() { decke.remove(); }
    function abbrechen() { zu(); beiAbbruch(); }
    decke.addEventListener("mousedown", function (ev) {
      if (ev.target === decke) abbrechen(); });

    var titel = doc.createElement("div");
    titel.className = "tbx-titel";
    titel.textContent = TE().eegTitel + " — " +
      ((v && v.name) ? v.name : kuerzel);
    karte.appendChild(titel);

    var flaeche = doc.createElement("div");
    flaeche.className = "tbx-eeg-flaeche";
    karte.appendChild(flaeche);

    var vorschau = doc.createElement("div");
    vorschau.className = "tbx-eeg-vorschau";
    karte.appendChild(vorschau);

    function frisch() {
      var f = flt();
      vorschau.innerHTML =
        "<p><u>" + TE().eegIndikation + "</u></p>" + f.indikation.html +
        "<p>&nbsp;</p><p><u>" + TE().eegAnamnese + "</u></p>" + f.anamnese.html +
        "<p>&nbsp;</p>" + TB.eeg.block(f).html;
    }

    function abschnitt(text) {
      var kt = doc.createElement("div");
      kt.className = "tbx-eeg-abschnitt";
      kt.textContent = text;
      flaeche.appendChild(kt);
    }
    function baueBereich(bereich) {
      var letzteKat = "";
      sichtbar.forEach(function (id) {
        var p = TB.eeg.punkt(m, id);
        if (!p) return;
        var kat = m.kategorien.find(function (k) {
          return k.id === p.kategorie; });
        if (!kat || (kat.bereich || "befund") !== bereich) return;
        if (p.kategorie !== letzteKat) {
          letzteKat = p.kategorie;
          var kt = doc.createElement("div");
          kt.className = "tbx-eeg-kat";
          kt.textContent = kat.name;
          flaeche.appendChild(kt);
        }
        flaeche.appendChild(zeile(p));
      });
      flaeche.appendChild(dazuZeile(bereich));
    }

    function baue() {
      flaeche.textContent = "";
      abschnitt(TE().eegIndikation);
      baueBereich("indikation");
      abschnitt(TE().eegAnamnese);
      baueBereich("anamnese");
      flaeche.appendChild(mediBlock());
      abschnitt(TE().eegBefundTitel);
      flaeche.appendChild(dreiknopfBlock());
      baueBereich("befund");
      flaeche.appendChild(zeilenBlock());
      abschnitt(TE().eegAutoTitel);
      TB.eeg.autoBeurteilung(gewaehlt, werte, aktiveZeilen())
        .forEach(function (a) { flaeche.appendChild(autoZeile(a)); });
      abschnitt(TE().eegBeurteilungTitel);
      baueBereich("beurteilung");
      frisch();
    }

    // ---- Dreiknopf-Zeilen und Artefakte ---------------------------------
    function knopfreihe(beschriftung, namen, istAktiv, beiKlick) {
      var z = doc.createElement("div");
      z.className = "tbx-eeg-dreiknopf";
      var l = doc.createElement("span");
      l.className = "tbx-eeg-dreiknopf-label";
      l.textContent = beschriftung;
      z.appendChild(l);
      namen.forEach(function (name, i) {
        var k = doc.createElement("button");
        k.type = "button";
        k.className = "tbx-knopf tbx-eeg-wahl" +
          (istAktiv(i) ? " tbx-eeg-wahl-aktiv" : "");
        k.textContent = name;
        k.addEventListener("click", function () { beiKlick(i); baue(); });
        z.appendChild(k);
      });
      return z;
    }
    function dreiknopfBlock() {
      var w = doc.createElement("div");
      w.appendChild(knopfreihe(TE().eegAbleitung,
        R().ableitungKnoepfe.map(function (k) { return k.name; }),
        function (i) { return i === ablWahl; }, setzeAbleitung));
      w.appendChild(knopfreihe(TE().eegVigilanz,
        R().vigilanzKnoepfe.map(function (k) { return k.name; }),
        function (i) { return i === vigWahl; }, setzeVigilanz));
      var z = doc.createElement("div");
      z.className = "tbx-eeg-dreiknopf";
      var l = doc.createElement("span");
      l.className = "tbx-eeg-dreiknopf-label";
      l.textContent = TE().eegArtefakte;
      z.appendChild(l);
      var namen = { art_augen: TE().eegArtAugen,
        art_muskel: TE().eegArtMuskel, art_bewegung: TE().eegArtBewegung };
      R().artefaktKaestchen.forEach(function (pid) {
        var lab = doc.createElement("label");
        lab.className = "tbx-eeg-artefakt";
        var kr = doc.createElement("input");
        kr.type = "checkbox";
        kr.checked = !!gewaehlt[pid];
        kr.addEventListener("change", function () {
          gewaehlt[pid] = kr.checked;
          if (kr.checked) zeigePunkt(pid);
          frisch();
        });
        lab.appendChild(kr);
        lab.appendChild(doc.createTextNode(" " + namen[pid]));
        z.appendChild(lab);
      });
      w.appendChild(z);
      return w;
    }

    // ---- Medikamenten-Zeilen --------------------------------------------
    function mediBlock() {
      var w = doc.createElement("div");
      var kopf = doc.createElement("div");
      kopf.className = "tbx-eeg-kat";
      kopf.textContent = TE().eegMediTitel;
      w.appendChild(kopf);
      medis.forEach(function (mz) {
        var z = doc.createElement("div");
        z.className = "tbx-eeg-medi";
        var ddl = doc.createElement("select");
        var leer = doc.createElement("option");
        leer.value = ""; leer.textContent = "—";
        ddl.appendChild(leer);
        R().antikonvulsiva.concat([R().mediFreitext]).forEach(function (n) {
          var opt = doc.createElement("option");
          opt.value = n; opt.textContent = n;
          ddl.appendChild(opt);
        });
        ddl.value = mz.name;
        ddl.addEventListener("change", function () {
          mz.name = ddl.value; frisch(); });
        z.appendChild(ddl);
        var dos = doc.createElement("input");
        dos.type = "text"; dos.className = "tbx-eeg-feld";
        dos.placeholder = TE().eegMediDosis;
        dos.value = mz.dosis;
        dos.addEventListener("input", function () {
          mz.dosis = dos.value; frisch(); });
        z.appendChild(dos);
        var fr = doc.createElement("input");
        fr.type = "text"; fr.className = "tbx-eeg-frei";
        fr.placeholder = TE().eegMediFrei;
        fr.value = mz.frei;
        fr.addEventListener("input", function () {
          mz.frei = fr.value; frisch(); });
        z.appendChild(fr);
        w.appendChild(z);
      });
      var mehr = doc.createElement("button");
      mehr.type = "button";
      mehr.className = "tbx-knopf";
      mehr.textContent = TE().eegMediMehr;
      mehr.addEventListener("click", function () {
        if (medis.length >= 6) return;
        medis.push({ name: "", dosis: "", frei: "" });
        baue();
      });
      w.appendChild(mehr);
      return w;
    }

    // ---- Herd-, Transienten- und Entladungs-Zeilen ----------------------
    function auswahl(optionen, wert, beiWahl) {
      var ddl = doc.createElement("select");
      optionen.forEach(function (o) {
        var opt = doc.createElement("option");
        opt.value = o; opt.textContent = o === "" ? "—" : o;
        ddl.appendChild(opt);
      });
      ddl.value = wert;
      ddl.addEventListener("change", function () { beiWahl(ddl.value); });
      return ddl;
    }
    function zeilenZeile(art, z, beschriftung) {
      var r = R();
      var w = doc.createElement("div");
      w.className = "tbx-eeg-zeile";
      var kr = doc.createElement("input");
      kr.type = "checkbox";
      kr.checked = z.aktiv;
      kr.title = TE().eegZeileAktiv;
      kr.addEventListener("change", function () {
        z.aktiv = kr.checked; baue(); });
      w.appendChild(kr);
      var l = doc.createElement("span");
      l.className = "tbx-eeg-zeilenwort";
      l.textContent = beschriftung;
      w.appendChild(l);
      function an(wertSetzen) {
        return function (wert) {
          wertSetzen(wert);
          z.aktiv = true; kr.checked = true;
          baue();
        };
      }
      var haeuf = (art === "herde") ? r.herdHaeufigkeiten
        : (art === "entladungen") ? r.entHaeufigkeiten : r.transHaeufigkeiten;
      w.appendChild(auswahl(haeuf, z.haeufigkeit,
        an(function (x) { z.haeufigkeit = x; })));
      if (art === "herde") {
        w.appendChild(auswahl(r.baender.map(function (b) { return b.wort; }),
          (r.baender.find(function (b) { return b.id === z.band; }) ||
            r.baender[0]).wort,
          an(function (x) {
            var b = r.baender.find(function (y) { return y.wort === x; });
            z.band = b ? b.id : z.band;
          })));
      }
      if (art === "entladungen") {
        w.appendChild(auswahl(r.entFormen, z.form,
          an(function (x) { z.form = x; })));
      }
      var lok1 = [""].concat(r.regionen.map(function (x) { return x.id; }),
        r.spezialLok);
      var lokN = [""].concat(r.regionen.map(function (x) { return x.id; }));
      z.lok.forEach(function (g, i) {
        w.appendChild(auswahl(i === 0 ? lok1 : lokN, g,
          an(function (x) { z.lok[i] = x; })));
      });
      w.appendChild(auswahl(r.seiten, z.seite,
        an(function (x) { z.seite = x; })));
      w.appendChild(auswahl(r.ausbreitungen, z.ausbreitung,
        an(function (x) { z.ausbreitung = x; })));
      return w;
    }
    function zeilenBlock() {
      var w = doc.createElement("div");
      var kopf = doc.createElement("div");
      kopf.className = "tbx-eeg-kat";
      kopf.textContent = TE().eegZeilenTitel;
      w.appendChild(kopf);
      zeilen.herde.forEach(function (z, i) {
        w.appendChild(zeilenZeile("herde", z, TE().eegHerdWort + " " + (i + 1))); });
      zeilen.transienten.forEach(function (z, i) {
        w.appendChild(zeilenZeile("transienten", z,
          TE().eegTransKurz + " " + (i + 1))); });
      zeilen.entladungen.forEach(function (z, i) {
        w.appendChild(zeilenZeile("entladungen", z,
          TE().eegEntWort + " " + (i + 1))); });
      [["herde", 4, TE().eegMehrHerd], ["transienten", 2, TE().eegMehrTrans],
       ["entladungen", 3, TE().eegMehrEnt]].forEach(function (e) {
        var k = doc.createElement("button");
        k.type = "button";
        k.className = "tbx-knopf";
        k.textContent = e[2];
        k.addEventListener("click", function () {
          if (zeilen[e[0]].length >= e[1]) return;
          zeilen[e[0]].push(neueZeile(e[0]));
          baue();
        });
        w.appendChild(k);
      });
      return w;
    }

    // ---- Kern-Beurteilung (überschreibbar) ------------------------------
    function autoZeile(a) {
      autoSoll[a.id] = a.text;
      var z = doc.createElement("div");
      z.className = "tbx-eeg-zeile";
      var satz = doc.createElement("span");
      satz.className = "tbx-eeg-satz";
      if (abw[a.id] !== undefined) {
        var b = doc.createElement("b");
        b.textContent = abw[a.id];
        satz.appendChild(b);
      } else {
        satz.textContent = a.text;
      }
      z.appendChild(satz);
      var stift = doc.createElement("button");
      stift.type = "button";
      stift.className = "tbx-eeg-stift";
      stift.textContent = abw[a.id] !== undefined ? "↺" : "✎";
      stift.title = abw[a.id] !== undefined
        ? TE().eegZurueckVorgabe : TE().eegUeberschreiben;
      stift.addEventListener("click", function () {
        if (abw[a.id] !== undefined) { delete abw[a.id]; baue(); return; }
        var neu = doc.defaultView.prompt(TE().eegUeberschreiben, a.text);
        if (neu === null) return;
        neu = neu.trim();
        if (!neu || neu === a.text.trim()) delete abw[a.id];
        else abw[a.id] = neu;
        baue();
      });
      z.appendChild(stift);
      return z;
    }

    function zeile(p) {
      var z = doc.createElement("div");
      z.className = "tbx-eeg-zeile";
      var kreuz = doc.createElement("input");
      kreuz.type = "checkbox";
      kreuz.checked = !!gewaehlt[p.id];
      kreuz.addEventListener("change", function () {
        gewaehlt[p.id] = kreuz.checked; frisch(); });
      z.appendChild(kreuz);

      var satz = doc.createElement("span");
      satz.className = "tbx-eeg-satz";
      if (abw[p.id] !== undefined) {
        var b = doc.createElement("b");
        b.textContent = abw[p.id];
        satz.appendChild(b);
      } else {
        TB.eeg.zerlege(p.text).forEach(function (s) {
          if (s.art === "text") {
            satz.appendChild(doc.createTextNode(s.wert));
          } else if (s.art === "auswahl") {
            var ddl = doc.createElement("select");
            s.optionen.forEach(function (o) {
              var opt = doc.createElement("option");
              opt.value = o; opt.textContent = o === "" ? "—" : o;
              ddl.appendChild(opt);
            });
            ddl.value = TB.eeg.wertVon(s, werte, p.id);
            ddl.title = s.label;
            ddl.addEventListener("change", function () {
              (werte[p.id] = werte[p.id] || {})[s.label] = ddl.value;
              gewaehlt[p.id] = true; kreuz.checked = true; frisch();
            });
            satz.appendChild(ddl);
          } else {
            var ein = doc.createElement("input");
            ein.type = "text";
            ein.className = "tbx-eeg-feld";
            ein.value = TB.eeg.wertVon(s, werte, p.id);
            ein.placeholder = s.label; ein.title = s.label;
            ein.addEventListener("input", function () {
              (werte[p.id] = werte[p.id] || {})[s.label] = ein.value;
              gewaehlt[p.id] = true; kreuz.checked = true; frisch();
            });
            satz.appendChild(ein);
          }
        });
      }
      z.appendChild(satz);

      var stift = doc.createElement("button");
      stift.type = "button";
      stift.className = "tbx-eeg-stift";
      stift.textContent = abw[p.id] !== undefined ? "↺" : "✎";
      stift.title = abw[p.id] !== undefined
        ? TE().eegZurueckVorgabe : TE().eegUeberschreiben;
      stift.addEventListener("click", function () {
        if (abw[p.id] !== undefined) { delete abw[p.id]; baue(); return; }
        var neu = doc.defaultView.prompt(TE().eegUeberschreiben,
          TB.eeg.aufgeloest(p, werte));
        if (neu === null) return;
        neu = neu.trim();
        if (!neu || neu === TB.eeg.aufgeloest(p, werte).trim()) delete abw[p.id];
        else { abw[p.id] = neu; gewaehlt[p.id] = true; }
        baue();
      });
      z.appendChild(stift);
      return z;
    }

    function dazuZeile(bereich) {
      var z = doc.createElement("div");
      z.className = "tbx-eeg-dazu";
      var ddl = doc.createElement("select");
      var leer = doc.createElement("option");
      leer.value = ""; leer.textContent = TE().eegDazu;
      ddl.appendChild(leer);
      m.punkte.forEach(function (p) {
        var kat = m.kategorien.find(function (k) {
          return k.id === p.kategorie; });
        if (!kat || (kat.bereich || "befund") !== bereich) return;
        if (sichtbar.indexOf(p.id) !== -1) return;
        var opt = doc.createElement("option");
        opt.value = p.id;
        opt.textContent = kat.name + ": " +
          p.text.replace(/\{\{(Auswahl|Feld):([^:}=]+)[^}]*\}\}/g, "<$2>")
            .slice(0, 70);
        ddl.appendChild(opt);
      });
      ddl.addEventListener("change", function () {
        if (!ddl.value) return;
        sichtbar.push(ddl.value);
        gewaehlt[ddl.value] = true;
        baue();
      });
      z.appendChild(ddl);
      return z;
    }

    var knoepfe = doc.createElement("div");
    knoepfe.className = "tbx-knopfzeile";
    function knopf(text, klasse, beiKlick) {
      var k = doc.createElement("button");
      k.type = "button";
      k.className = "tbx-knopf" + (klasse ? " " + klasse : "");
      k.textContent = text;
      k.addEventListener("click", beiKlick);
      knoepfe.appendChild(k);
    }
    knopf(TE().eegEinfuegen, "tbx-eeg-einfuegen", function () {
      var f = flt();
      zu();
      beiFertig(TB.eeg.block(f));
    });
    knopf(TE().eegIndKopieren, "", function () {
      H().inZwischenablage(flt().indikation);
    });
    knopf(TE().eegAnamKopieren, "", function () {
      H().inZwischenablage(flt().anamnese);
    });
    knopf(TE().eegKopieren, "", function () {
      H().inZwischenablage(TB.eeg.block(flt()));
    });
    knopf(TE().abbrechen, "", abbrechen);
    karte.appendChild(knoepfe);

    karte.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") { ev.stopPropagation(); abbrechen(); }
    });

    baue();
    doc.body.appendChild(decke);
    karte.tabIndex = -1;
    karte.focus();
  }

  return { starte: starte };
})();
