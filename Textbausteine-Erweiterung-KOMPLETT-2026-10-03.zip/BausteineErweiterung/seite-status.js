// Datei: seite-status.js
// Projekt: Textbausteine — Teil: Chrome-Erweiterung
// Zweck: Das Status-Fenster auf einer Seite (Etappe 11): ;;statuscts,
//        ;;statusstroke, ;;statusc7 … (das Kürzel jedes Status aus
//        der Status-Pflege der App) öffnet das Fenster über der Seite
//        mit GENAU diesem Status: die Punkte angekreuzt, Näds eigene
//        Standardtexte als Normalbefund, Zusätze sichtbar aber nicht
//        angewählt, die gespeicherte Muskel-Auswahl angewandt. Die
//        ganze Logik (normalVon, fliesstext, wortUnterschied) liefert
//        status.js als byteweise App-Kopie — TB.statusQuelle unten
//        ist ihre nur-lesende Datenquelle (Migrationen laufen hier
//        nie, das regelt status.js über TB.speicher). Einfügen setzt
//        EINEN Block an der gemerkten Stelle; Überschriebenes
//        erscheint fett in Dunkelgrau. Esc bricht ab, das Kürzel
//        kommt zurück. GRUNDSATZ: nichts wird gespeichert, keine
//        Patientendaten verlassen die Seite.

"use strict";
window.TB = window.TB || {};

// Die Datenquelle für status.js: die abgeglichenen Einstellungen der
// Erweiterung — bei jedem Zugriff frisch, nur lesend.
TB.statusQuelle = {
  einstellung: function (name, vorgabe) {
    var H = TB.seite && TB.seite.maskenHelfer;
    var e = H && H.einstellungen ? H.einstellungen() : {};
    return (e && e[name] !== undefined && e[name] !== null) ? e[name] : vorgabe;
  }
};

TB.seiteStatus = (function () {
  function H() { return TB.seite.maskenHelfer; }
  function TE() { return TB.TE; }
  function TS() { return TB.statusTexte; }

  function starte(ort, kuerzel, urspruenglich) {
    var m = TB.status.master();
    var t = TB.status.teilmengeMitKuerzel(kuerzel);
    if (!m || !t) { H().meldung(TE().statusKeineDaten, true); return; }
    var zurueck = H().halteStelle(ort);
    oeffneFenster(m, t, function (erg) {
      var ziel = zurueck();
      var ok;
      if (ziel.art === "feld") { H().schreibeText(ziel, erg.text); ok = true; }
      else { ok = H().schreibeHtml(ziel, erg.html, null); }
      if (!ok) { H().inZwischenablage(erg); }
    }, function () {
      if (urspruenglich) H().schreibeText(zurueck(), urspruenglich);
      else zurueck();
    });
  }

  // ---- Das Fenster ------------------------------------------------------
  function oeffneFenster(m, t, beiFertig, beiAbbruch) {
    var doc = H().obersteTuer();
    var gewaehlt = {}, sichtbar = [], abw = {};
    var merkmalWahl = {}, merkmalZusatz = {}, normalUeber = {};
    (t.punkte || []).forEach(function (uid) {
      sichtbar.push(uid); gewaehlt[uid] = true; });
    (t.zusatz || []).forEach(function (uid) {
      if (sichtbar.indexOf(uid) === -1) sichtbar.push(uid); });
    Object.keys(t.normalAb || {}).forEach(function (uid) {
      normalUeber[uid] = t.normalAb[uid]; });
    Object.keys(t.merkmalAb || {}).forEach(function (uid) {
      var ab = {};
      t.merkmalAb[uid].forEach(function (mid) { ab[mid] = true; });
      merkmalWahl[uid] = ab;
    });
    Object.keys(t.merkmalZusatz || {}).forEach(function (uid) {
      var zs = {};
      t.merkmalZusatz[uid].forEach(function (mid) { zs[mid] = true; });
      merkmalZusatz[uid] = zs;
    });

    function flt() {
      return TB.status.fliesstext(m, gewaehlt, abw, merkmalWahl, normalUeber);
    }

    var decke = doc.createElement("div");
    decke.className = "tbx-decke";
    decke.setAttribute("data-tb-status", "");
    var karte = doc.createElement("div");
    karte.className = "tbx-karte tbx-maske tbx-eeg-karte";
    decke.appendChild(karte);

    function zu() { decke.remove(); }
    function abbrechen() { zu(); beiAbbruch(); }
    decke.addEventListener("mousedown", function (ev) {
      if (ev.target === decke) abbrechen(); });

    var titel = doc.createElement("div");
    titel.className = "tbx-titel";
    titel.textContent = TE().statusTitel + " — " + (t.name || "");
    karte.appendChild(titel);

    var flaeche = doc.createElement("div");
    flaeche.className = "tbx-eeg-flaeche";
    karte.appendChild(flaeche);

    var vorschau = doc.createElement("div");
    vorschau.className = "tbx-eeg-vorschau";
    karte.appendChild(vorschau);

    function frisch() { vorschau.innerHTML = flt().html; }

    function normalVon(u) {
      return TB.status.normalVon(u, merkmalWahl, normalUeber);
    }
    function merkmalAn(uid, mid) {
      return !(merkmalWahl[uid] && merkmalWahl[uid][mid]);
    }

    function baue() {
      flaeche.textContent = "";
      m.kategorien.forEach(function (k) {
        var teile = m.untersuchungen.filter(function (u) {
          return u.kategorie === k.id && sichtbar.indexOf(u.id) !== -1; });
        if (!teile.length) return;
        var kt = doc.createElement("div");
        kt.className = "tbx-eeg-kat";
        kt.textContent = k.name;
        flaeche.appendChild(kt);
        teile.forEach(function (u) { flaeche.appendChild(zeile(u)); });
      });
      flaeche.appendChild(dazuZeile());
      frisch();
    }

    function zeile(u) {
      var uid = u.id;
      var z = doc.createElement("div");
      z.className = "tbx-eeg-zeile";
      var kreuz = doc.createElement("input");
      kreuz.type = "checkbox";
      kreuz.checked = !!gewaehlt[uid];
      kreuz.addEventListener("change", function () {
        gewaehlt[uid] = kreuz.checked; frisch(); });
      z.appendChild(kreuz);
      var name = doc.createElement("span");
      name.className = "tbx-status-name";
      name.textContent = u.name + ":";
      z.appendChild(name);
      var satz = doc.createElement("span");
      satz.className = "tbx-eeg-satz";
      if (abw[uid] !== undefined) {
        var b = doc.createElement("b");
        b.textContent = abw[uid];
        satz.appendChild(b);
      } else {
        satz.textContent = normalVon(u);
      }
      z.appendChild(satz);
      var stift = doc.createElement("button");
      stift.type = "button";
      stift.className = "tbx-eeg-stift";
      stift.textContent = abw[uid] !== undefined ? "↺" : "✎";
      stift.title = abw[uid] !== undefined
        ? TE().eegZurueckVorgabe : TE().eegUeberschreiben;
      stift.addEventListener("click", function () {
        if (abw[uid] !== undefined) { delete abw[uid]; baue(); return; }
        var neu = doc.defaultView.prompt(TE().eegUeberschreiben,
          String(normalVon(u)));
        if (neu === null) return;
        neu = neu.trim();
        if (!neu || neu === String(normalVon(u)).trim()) delete abw[uid];
        else { abw[uid] = neu; gewaehlt[uid] = true; }
        baue();
      });
      z.appendChild(stift);
      if (u.merkmale) {
        var an = u.merkmale.filter(function (mk) {
          return merkmalAn(uid, mk.id); }).length;
        var km = doc.createElement("button");
        km.type = "button";
        km.className = "tbx-knopf tbx-status-muskeln";
        km.textContent = TE().statusMuskeln + " " + an + "/" +
          u.merkmale.length;
        km.addEventListener("click", function () {
          var offen = z.querySelector(".tbx-status-muskelliste");
          if (offen) { offen.remove(); return; }
          z.appendChild(muskelListe(u));
        });
        z.appendChild(km);
      }
      if (u.hinweis) {
        var h = doc.createElement("div");
        h.className = "tbx-status-hinweis";
        h.textContent = u.hinweis;
        z.appendChild(h);
      }
      return z;
    }

    // Muskel-Liste direkt in der Zeile (Häkchen = Muskel im Befund;
    // ☆ = Zusatz-Kandidat des Status).
    function muskelListe(u) {
      var uid = u.id;
      var w = doc.createElement("div");
      w.className = "tbx-status-muskelliste";
      u.merkmale.forEach(function (mk) {
        var lab = doc.createElement("label");
        lab.className = "tbx-status-muskel";
        var kr = doc.createElement("input");
        kr.type = "checkbox";
        kr.checked = merkmalAn(uid, mk.id);
        kr.addEventListener("change", function () {
          merkmalWahl[uid] = merkmalWahl[uid] || {};
          if (kr.checked) delete merkmalWahl[uid][mk.id];
          else merkmalWahl[uid][mk.id] = true;
          baue();
        });
        lab.appendChild(kr);
        var stern = (merkmalZusatz[uid] && merkmalZusatz[uid][mk.id])
          ? "☆ " : "";
        lab.appendChild(doc.createTextNode(" " + stern + mk.name));
        w.appendChild(lab);
      });
      return w;
    }

    function dazuZeile() {
      var z = doc.createElement("div");
      z.className = "tbx-eeg-dazu";
      var ddl = doc.createElement("select");
      var leer = doc.createElement("option");
      leer.value = ""; leer.textContent = TE().statusDazu;
      ddl.appendChild(leer);
      m.untersuchungen.forEach(function (u) {
        if (sichtbar.indexOf(u.id) !== -1) return;
        var kat = m.kategorien.find(function (k) {
          return k.id === u.kategorie; });
        var opt = doc.createElement("option");
        opt.value = u.id;
        opt.textContent = (kat ? kat.name : "") + ": " + u.name;
        ddl.appendChild(opt);
      });
      ddl.addEventListener("change", function () {
        if (!ddl.value) return;
        sichtbar.push(ddl.value);
        gewaehlt[ddl.value] = true;
        baue();
      });
      z.appendChild(ddl);
      return z;
    }

    var knoepfe = doc.createElement("div");
    knoepfe.className = "tbx-knopfzeile";
    var ok = doc.createElement("button");
    ok.type = "button";
    ok.className = "tbx-knopf tbx-eeg-einfuegen";
    ok.textContent = TE().statusEinfuegen;
    ok.addEventListener("click", function () {
      var f = flt();
      zu();
      beiFertig(f);
    });
    knoepfe.appendChild(ok);
    var kopie = doc.createElement("button");
    kopie.type = "button";
    kopie.className = "tbx-knopf";
    kopie.textContent = TE().statusKopieren;
    kopie.addEventListener("click", function () {
      H().inZwischenablage(flt());
    });
    knoepfe.appendChild(kopie);
    var weg = doc.createElement("button");
    weg.type = "button";
    weg.className = "tbx-knopf";
    weg.textContent = TE().abbrechen;
    weg.addEventListener("click", abbrechen);
    knoepfe.appendChild(weg);
    karte.appendChild(knoepfe);

    karte.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape") { ev.stopPropagation(); abbrechen(); }
    });

    baue();
    doc.body.appendChild(decke);
    karte.tabIndex = -1;
    karte.focus();
  }

  return { starte: starte };
})();
