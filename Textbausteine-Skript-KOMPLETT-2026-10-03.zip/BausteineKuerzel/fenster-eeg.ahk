﻿; Datei: fenster-eeg.ahk
; Projekt: Textbausteine - Teil: Windows-Skript (AutoHotkey v2)
; Zweck: Der EEG-Schnell-Befund direkt in KISIM (Etappe 11): ;;eeg im
;        Feld Indikation/Fragestellung oeffnet dieses Fenster. Katalog
;        und Vorlagen kommen aus den abgeglichenen Einstellungen
;        (eegMaster/eegVorlagen) - gepflegt wird NUR in der App. Drei
;        Reiter: Indikation & Anamnese (mit Medikamenten-Zeilen),
;        Befund (Dreiknopf Ableitung/Vigilanz, Artefakte, Herd-,
;        Transienten- und Entladungs-Zeilen) und Beurteilung (die
;        Automatik baut sie aus dem Befund, jeder Satz per Stift
;        ueberschreibbar). "Alles einfuegen" schreibt die vier
;        KISIM-Felder der Reihe nach und springt selbst mit Strg+Tab
;        (2 - 4 - 2, als Sicherheitsventil im Fenster aenderbar);
;        am Ende steht die Schreibmarke hinter der Beurteilung.
;        Die REGELN unten sind ein GENERIERTER Spiegel von
;        eeg-grundlage.js - nie von Hand aendern, die Pruefsuite
;        vergleicht sie gegen die App. Fensterketten als flache
;        Zustands-Kette mit SetTimer nach Destroy (Lehre K1).
;        GRUNDSATZ: nichts wird gespeichert, nichts verlaesst den
;        Rechner - der Befund lebt nur in diesem Fenster.

global eegFenster := ""
global eegZiel := 0
global eegSt := ""
global eegRegelnLager := ""

; ---- GENERIERTER REGELN-SPIEGEL (Quelle: eeg-grundlage.js) --------------
EegRegeln() {
    global eegRegelnLager
    if (eegRegelnLager != "")
        return eegRegelnLager
    r := Map()
    r["avNormalAb"] := 8
    r["avLeichtAb"] := 6
    r["avSaetze"] := Map("normal", "Normaler Grundrhythmus.", "leicht", "Leichte Allgemeinveränderung.", "mittel", "Mittelschwere Allgemeinveränderung.")
    r["fgrdaBeurteilung"] := "Intermittierende fGRDA."
    r["gaNbBeurteilung"] := "Grundaktivität nicht beurteilbar."
    r["herdHaeufigkeiten"] := ["Vereinzelt", "Wiederholt", "Intermittierend", "Kontinuierlich"]
    r["baender"] := [Map("id", "theta", "wort", "Theta-Band", "herd", "Leichter", "gen", "Leichte"), Map("id", "theta-delta", "wort", "Theta-Delta-Band", "herd", "Mässiggradiger", "gen", "Mässiggradige"), Map("id", "delta-theta", "wort", "Delta-Theta-Band", "herd", "Mittelschwerer", "gen", "Mittelschwere"), Map("id", "delta", "wort", "Delta-Band", "herd", "Schwerer", "gen", "Schwere"), Map("id", "subdelta", "wort", "Subdelta-Band", "herd", "Schwerer", "gen", "Schwere", "zusatz", " (mit Subdelta-Wellen)")]
    r["regionen"] := [Map("id", "frontal", "binde", "fronto"), Map("id", "temporal", "binde", "temporo"), Map("id", "parietal", "binde", "parieto"), Map("id", "okzipital", "binde", "okzipito"), Map("id", "zentral", "binde", "zentro")]
    r["spezialLok"] := ["generalisiert", "hemisphärisch"]
    r["seiten"] := ["", "links", "rechts", "bds.", "bds. linksbetont", "bds. rechtsbetont"]
    r["ausbreitungen"] := ["", "bis zur Mittellinie", "bis zur Gegenseite", "bis frontal", "bis temporal", "bis parietal", "bis okzipital", "bis zentral"]
    r["entHaeufigkeiten"] := ["Vereinzelte", "Wiederholte", "Intermittierende", "Kontinuierliche"]
    r["entFormen"] := ["Spike-Wave-Komplexe", "Spikes", "Sharp-Wave-Komplexe", "Polyspikes", "Polyspike-Wave-Komplexe", "Sharp-Slow-Wave-Komplexe"]
    r["ableitungKnoepfe"] := [Map("name", "Standard", "werte", Map("Montage", "10/20 + 6 true temporal Elektroden-Ableitung", "Bedingungen", "unter Standardbedingungen im EEG Stuhl"), "artefakt50", false), Map("name", "Notfall", "werte", Map("Montage", "10/20-Ableitung", "Bedingungen", "auf der Notfallliege"), "artefakt50", false), Map("name", "IPS", "werte", Map("Montage", "10/20-Ableitung", "Bedingungen", "im Bett auf der Intensivstation"), "artefakt50", true)]
    r["vigilanzKnoepfe"] := [Map("name", "wach, im Verlauf schläfrig", "wert", "wach, im Verlauf schläfrig mit Alpha-dropout und hypnagogen Thetawellen"), Map("name", "wach", "wert", "wach"), Map("name", "durchgehend schläfrig", "wert", "durchgehend schläfrig")]
    r["artefaktKaestchen"] := ["art_augen", "art_muskel", "art_bewegung"]
    r["herdeVorbereitet"] := 2
    r["entladungenVorbereitet"] := 1
    r["herdVorwahl"] := Map("haeufigkeit", "Intermittierend", "band", "theta-delta", "lok", ["temporal", "", "", ""], "ausbreitung", "", "seite", "")
    r["entVorwahl"] := Map("haeufigkeit", "Vereinzelte", "lok", ["temporal", "", "", ""], "ausbreitung", "", "seite", "")
    r["transHaeufigkeiten"] := ["Vereinzelt", "Wiederholt"]
    r["transSchluss"] := ", die Kriterien für epilepsietypische Potenziale jedoch nicht vollständig erfüllt"
    r["transWort"] := "eingelagerte steilere Transienten"
    r["grenzSatz"] := "%s eingeschränkte Beurteilbarkeit aufgrund von Artefakten."
    r["nichtDurchgefuehrt"] := "nicht durchgeführt."
    r["schlafStadien"] := ["N1", "N2", "N3", "REM"]
    r["schlafElemente"] := [Map("id", "vig_n1_vertex", "stadium", "N1"), Map("id", "vig_n1_theta", "stadium", "N1"), Map("id", "vig_n1_posts", "stadium", "N1"), Map("id", "vig_n2_spindeln", "stadium", "N2"), Map("id", "vig_n2_k", "stadium", "N2"), Map("id", "vig_n3_delta", "stadium", "N3"), Map("id", "vig_rem_saege", "stadium", "REM"), Map("id", "vig_rem_augen", "stadium", "REM")]
    r["schlafSatz"] := "Erreichen von Schlafstadium %s."
    r["keineHerde"] := "Keine Verlangsamungsherde."
    r["keineEtp"] := "Keine epilepsietypischen Potentiale."
    r["keineVariantenHerde"] := Map("keine.", "Keine Verlangsamungsherde.", "aufgrund ausgeprägter Artefakte nicht beurteilbar.", "Verlangsamungsherde nicht beurteilbar.", "bei ausgeprägten Artefakten soweit beurteilbar keine.", "Soweit beurteilbar keine Verlangsamungsherde.")
    r["keineVariantenEtp"] := Map("keine.", "Keine epilepsietypischen Potentiale.", "aufgrund ausgeprägter Artefakte nicht beurteilbar.", "Epilepsietypische Potentiale nicht beurteilbar.", "bei ausgeprägten Artefakten soweit beurteilbar keine.", "Soweit beurteilbar keine epilepsietypischen Potentiale.")
    r["indikationKnoepfe"] := [Map("id", "ind_standard", "name", "Standard"), Map("id", "ind_demenz", "name", "Demenzabklärung"), Map("id", "ind_status", "name", "Status")]
    r["antikonvulsiva"] := ["Lamotrigin", "Levetiracetam", "Brivaracetam", "Lacosamid", "Valproat", "Carbamazepin", "Cenobamat", "Eslicarbazepin", "Ethosuximid", "Gabapentin", "Oxcarbazepin", "Perampanel", "Phenobarbital", "Phenytoin", "Pregabalin", "Primidon", "Rufinamid", "Sultiam", "Topiramat", "Vigabatrin", "Zonisamid", "Clobazam", "Clonazepam", "Diazepam", "Lorazepam", "Midazolam", "Oxazepam"]
    r["mediFreitext"] := "anderes …"
    r["medisVorbereitet"] := 1
    r["kisimSpruenge"] := Map("nachAnamnese", 2, "nachBefund", 4, "nachBeurteilung", 2)
    r["etpWort"] := "Epilepsietypische Potentiale"
    r["etpGeneralisiert"] := "Generalisierte epilepsietypische Potentiale"
    r["verlangsamungGen"] := "generalisierte Verlangsamung"
    r["herdWort"] := "Verlangsamungsherd"
    eegRegelnLager := r
    return r
}

; ---- Zugriff auf Katalog und Vorlagen -----------------------------------
EegMaster() {
    global einstellungen
    if (einstellungen.Has("eegMaster") and einstellungen["eegMaster"] is Map)
        return einstellungen["eegMaster"]
    return ""
}
EegVorlagen() {
    global einstellungen
    if (einstellungen.Has("eegVorlagen") and einstellungen["eegVorlagen"] is Array)
        return einstellungen["eegVorlagen"]
    return []
}
EegVorlageMitKuerzel(kuerzel) {
    for v in EegVorlagen() {
        if (v is Map and v.Has("kuerzel") and StrLower(String(v["kuerzel"])) = StrLower(kuerzel))
            return v
    }
    return ""
}
EegPunkt(m, id) {
    for p in m["punkte"] {
        if (p["id"] = id)
            return p
    }
    return ""
}

; ---- Punkt-Text zerlegen (Spiegel von eeg.js zerlege) -------------------
EegZerlege(text) {
    stuecke := []
    rest := String(text)
    muster := "\{\{(Auswahl|Feld):([^:}=]+?)(?::([^}]*)|=([^}]*))?\}\}"
    while (rest != "") {
        if !RegExMatch(rest, muster, &t) {
            stuecke.Push(Map("art", "text", "wert", rest))
            break
        }
        if (t.Pos > 1)
            stuecke.Push(Map("art", "text", "wert", SubStr(rest, 1, t.Pos - 1)))
        if (t[1] = "Auswahl") {
            stuecke.Push(Map("art", "auswahl", "label", Trim(t[2]),
                "optionen", StrSplit(t[3], "|")))
        } else {
            stuecke.Push(Map("art", "feld", "label", Trim(t[2]),
                "vorgabe", t[4]))
        }
        rest := SubStr(rest, t.Pos + t.Len)
    }
    return stuecke
}
EegWertVon(st, pid, stueck) {
    if (st["werte"].Has(pid) and st["werte"][pid].Has(stueck["label"]))
        return st["werte"][pid][stueck["label"]]
    if (stueck["art"] = "auswahl")
        return stueck["optionen"].Length ? stueck["optionen"][1] : ""
    return stueck["vorgabe"]
}
EegAufgeloest(st, p) {
    satz := ""
    for s in EegZerlege(p["text"])
        satz .= (s["art"] = "text") ? s["wert"] : EegWertVon(st, p["id"], s)
    return satz
}
EegMitPunkt(t) {
    s := Trim(String(t))
    if (s = "")
        return s
    letzt := SubStr(s, -1)
    return (letzt = "." or letzt = "!" or letzt = "?" or letzt = ":") ? s : s "."
}
EegGross(t) {
    s := String(t)
    return (s = "") ? s : StrUpper(SubStr(s, 1, 1)) SubStr(s, 2)
}

; ---- Herd-, Transienten- und Entladungs-Saetze (Spiegel eeg.js) ---------
EegBand(id) {
    for b in EegRegeln()["baender"]
        if (b["id"] = id)
            return b
    return EegRegeln()["baender"][1]
}
EegKette(lok) {
    glieder := []
    for g in lok
        if (g != "")
            glieder.Push(g)
    if !glieder.Length
        return ""
    if (glieder[1] = "generalisiert")
        return "generalisiert"
    if (glieder[1] = EegRegeln()["spezialLok"][2])
        return EegRegeln()["spezialLok"][2]
    kette := ""
    for i, g in glieder {
        if (i = glieder.Length) {
            kette .= g
        } else {
            binde := g
            for reg in EegRegeln()["regionen"]
                if (reg["id"] = g)
                    binde := reg["binde"]
            kette .= binde "-"
        }
    }
    return kette
}
EegLokMitSeite(z) {
    kette := EegKette(z["lok"])
    if (kette = "generalisiert")
        return "generalisiert"
    seite := z["seite"]
    return Trim(kette (seite != "" ? " " seite : ""))
}
EegAusbreitung(z) {
    if (z["ausbreitung"] = "")
        return ""
    if (EegKette(z["lok"]) = "generalisiert")
        return ""
    return ", mit Ausbreitung " z["ausbreitung"]
}
EegHerdBefund(z) {
    return z["haeufigkeit"] " eingelagerte Wellen aus dem "
        . EegBand(z["band"])["wort"] " " EegLokMitSeite(z) EegAusbreitung(z) "."
}
EegHerdBeurteilung(z) {
    b := EegBand(z["band"])
    zusatz := b.Has("zusatz") ? b["zusatz"] : ""
    if (EegKette(z["lok"]) = "generalisiert")
        return b["gen"] " " EegRegeln()["verlangsamungGen"] zusatz "."
    return b["herd"] " " EegRegeln()["herdWort"] " " EegLokMitSeite(z) zusatz "."
}
EegEntBefund(z) {
    if (EegKette(z["lok"]) = "generalisiert")
        return z["haeufigkeit"] " generalisierte " z["form"] "."
    return z["haeufigkeit"] " " z["form"] " " EegLokMitSeite(z) EegAusbreitung(z) "."
}
EegTransBefund(z) {
    lage := EegLokMitSeite(z)
    return z["haeufigkeit"] " " EegRegeln()["transWort"]
        . (lage != "" ? " " lage : "") EegAusbreitung(z)
        . EegRegeln()["transSchluss"] "."
}
EegEntBeurteilung(z) {
    if (EegKette(z["lok"]) = "generalisiert")
        return EegRegeln()["etpGeneralisiert"] "."
    return EegRegeln()["etpWort"] " " EegLokMitSeite(z) "."
}
EegAktive(st, art) {
    aktive := []
    for z in st[art]
        if z["aktiv"]
            aktive.Push(z)
    return aktive
}

; ---- Beurteilungs-Automatik (Spiegel von eeg.js autoBeurteilung) --------
EegHz(st) {
    for pid in ["ga_grundrhythmus", "ga_diffus"] {
        if !(st["gewaehlt"].Has(pid) and st["gewaehlt"][pid])
            continue
        roh := (st["werte"].Has(pid) and st["werte"][pid].Has("Frequenz"))
            ? st["werte"][pid]["Frequenz"]
            : (pid = "ga_diffus" ? "6" : "9")
        zahl := StrReplace(String(roh), ",", ".")
        if IsNumber(zahl)
            return Number(zahl)
    }
    return ""
}
EegAvSatz(hz) {
    r := EegRegeln()
    if (hz = "")
        return ""
    if (hz >= r["avNormalAb"])
        return r["avSaetze"]["normal"]
    if (hz >= r["avLeichtAb"])
        return r["avSaetze"]["leicht"]
    return r["avSaetze"]["mittel"]
}
EegSchlafStadium(st) {
    r := EegRegeln()
    tiefstes := ""
    tiefsteNr := 0
    for e in r["schlafElemente"] {
        if !(st["gewaehlt"].Has(e["id"]) and st["gewaehlt"][e["id"]])
            continue
        for nr, s in r["schlafStadien"] {
            if (s = e["stadium"] and nr > tiefsteNr) {
                tiefsteNr := nr
                tiefstes := s
            }
        }
    }
    return tiefstes
}
EegKeineSatz(st, pid, tabelle, vorgabe) {
    wert := (st["werte"].Has(pid) and st["werte"][pid].Has("Befund"))
        ? st["werte"][pid]["Befund"] : "keine."
    return tabelle.Has(wert) ? tabelle[wert] : vorgabe
}
EegAutoSaetze(st) {
    r := EegRegeln()
    g := st["gewaehlt"]
    an(pid) => g.Has(pid) and g[pid]
    saetze := []
    if an("art_grenze") {
        grad := (st["werte"].Has("art_grenze") and st["werte"]["art_grenze"].Has("Grad"))
            ? st["werte"]["art_grenze"]["Grad"] : "leicht"
        saetze.Push(Map("id", "auto_grenze",
            "text", StrReplace(r["grenzSatz"], "%s", EegGross(grad))))
    }
    if an("ga_nb") {
        saetze.Push(Map("id", "auto_ganb", "text", r["gaNbBeurteilung"]))
    } else {
        av := EegAvSatz(EegHz(st))
        if (av != "")
            saetze.Push(Map("id", "auto_av", "text", av))
    }
    if an("ga_fgrda")
        saetze.Push(Map("id", "auto_fgrda", "text", r["fgrdaBeurteilung"]))
    stadium := EegSchlafStadium(st)
    if (stadium != "")
        saetze.Push(Map("id", "auto_schlaf",
            "text", StrReplace(r["schlafSatz"], "%s", stadium)))
    herde := EegAktive(st, "herde")
    if herde.Length {
        for i, h in herde
            saetze.Push(Map("id", "auto_h" (i - 1), "text", EegHerdBeurteilung(h)))
    } else if an("vl_keine") {
        saetze.Push(Map("id", "auto_hkeine",
            "text", EegKeineSatz(st, "vl_keine", r["keineVariantenHerde"], r["keineHerde"])))
    }
    ent := EegAktive(st, "ent")
    if ent.Length {
        for i, e in ent
            saetze.Push(Map("id", "auto_e" (i - 1), "text", EegEntBeurteilung(e)))
    } else if an("ent_keine") {
        saetze.Push(Map("id", "auto_ekeine",
            "text", EegKeineSatz(st, "ent_keine", r["keineVariantenEtp"], r["keineEtp"])))
    }
    return saetze
}
EegSatzFertig(st, soll, id) {
    a := st["abw"].Has(id) ? st["abw"][id] : ""
    ist := (Trim(a) != "" and Trim(a) != Trim(soll))
    return EegMitPunkt(ist ? a : soll)
}

; ---- Fliesstext und RTF je Bereich (Spiegel von eeg.js bereichText) -----
EegMediSatz(st) {
    r := EegRegeln()
    teile := ""
    for mz in st["medis"] {
        name := (mz["name"] = r["mediFreitext"]) ? Trim(mz["frei"]) : mz["name"]
        if (name = "")
            continue
        dosis := Trim(mz["dosis"])
        if (dosis != "" and !InStr(StrLower(dosis), "mg"))
            dosis .= " mg"
        teile .= (teile != "" ? ", " : "") name (dosis != "" ? " " dosis : "")
    }
    return teile != "" ? teile "." : ""
}
EegBereich(st, bereich) {
    m := st["m"]
    r := EegRegeln()
    text := ""
    rtf := ""
    schonWas := false
    for k in m["kategorien"] {
        kb := k.Has("bereich") ? k["bereich"] : "befund"
        if (kb != bereich)
            continue
        teileIds := []
        for id in st["sichtbar"] {
            p := EegPunkt(m, id)
            if (p = "" or p["kategorie"] != k["id"])
                continue
            if (st["gewaehlt"].Has(id) and st["gewaehlt"][id])
                teileIds.Push(id)
        }
        zeilenS := []
        nachS := []
        if (bereich = "anamnese" and k.Has("zeilen") and k["zeilen"] = "medis") {
            satz := EegMediSatz(st)
            if (satz != "")
                nachS.Push(Map("id", "z_medis", "satz", satz))
        }
        if (bereich = "befund" and k.Has("zeilen") and k["zeilen"] != ""
            and k["zeilen"] != "medis") {
            liste := EegAktive(st, k["zeilen"] = "herde" ? "herde" : "ent")
            trans := (k["zeilen"] = "herde") ? EegAktive(st, "trans") : []
            if (liste.Length or trans.Length) {
                ohne := []
                for id in teileIds
                    if (id != "vl_keine" and id != "ent_keine")
                        ohne.Push(id)
                teileIds := ohne
                for i, z in liste
                    zeilenS.Push(Map("id", "z_" k["zeilen"] (i - 1),
                        "satz", k["zeilen"] = "herde" ? EegHerdBefund(z) : EegEntBefund(z)))
                for i, z in trans
                    zeilenS.Push(Map("id", "z_trans" (i - 1),
                        "satz", EegTransBefund(z)))
            }
        }
        if (bereich = "befund" and !teileIds.Length and !zeilenS.Length
            and (k["id"] = "hyperventilation" or k["id"] = "photostimulation"))
            zeilenS.Push(Map("id", "auto_" k["id"], "satz", r["nichtDurchgefuehrt"]))
        autoS := []
        if (bereich = "beurteilung" and k["id"] = "beurteilung")
            autoS := EegAutoSaetze(st)
        if (!teileIds.Length and !zeilenS.Length and !nachS.Length and !autoS.Length)
            continue
        zeileT := ""
        zeileR := ""
        anfuegen(fertig) {
            zeileT .= (zeileT != "" ? " " : "") fertig
            zeileR .= (zeileR != "" ? " " : "") BermcRtfText(fertig)
        }
        for a in autoS
            anfuegen(EegSatzFertig(st, a["text"], a["id"]))
        for zs in zeilenS
            anfuegen(EegSatzFertig(st, zs["satz"], zs["id"]))
        for id in teileIds {
            p := EegPunkt(m, id)
            soll := EegAufgeloest(st, p)
            a := st["abw"].Has(id) ? st["abw"][id] : ""
            ist := (Trim(a) != "" and Trim(a) != Trim(soll))
            anfuegen(EegMitPunkt(ist ? a : soll))
        }
        for zs in nachS
            anfuegen(EegSatzFertig(st, zs["satz"], zs["id"]))
        if (k.Has("absatz") and k["absatz"] and schonWas) {
            text .= "`r`n"
            rtf .= "\par "
        }
        if (k.Has("titel") and k["titel"]) {
            text .= k["name"] ": " zeileT "`r`n"
            rtf .= "\ul " BermcRtfText(k["name"]) "\ulnone : " zeileR "\par "
        } else {
            text .= zeileT "`r`n"
            rtf .= zeileR "\par "
        }
        schonWas := true
    }
    if (text != "")
        text := SubStr(text, 1, -2)
    return [text, rtf]
}

; ---- Oeffnen: Zustand aus der Vorlage -----------------------------------
EegOeffnen(ziel, kuerzel) {
    global eegZiel, eegSt
    m := EegMaster()
    if (m = "") {
        Toast(TX["eegKeinKatalog"], true)
        return
    }
    v := EegVorlageMitKuerzel(kuerzel)
    if (v != "" and v.Has("id") and v["id"] = "v_eegips") {
        Toast(TX["eegIpsSpaeter"], true)
        return
    }
    r := EegRegeln()
    eegZiel := ziel
    st := Map()
    st["m"] := m
    st["vname"] := (v != "" and v.Has("name")) ? v["name"] : kuerzel
    st["gewaehlt"] := Map()
    st["sichtbar"] := []
    st["werte"] := Map()
    st["abw"] := Map()
    st["autoSoll"] := Map()
    st["bearbeite"] := ""
    st["ablWahl"] := 1
    st["vigWahl"] := 1
    if (v != "") {
        if v.Has("punkte") {
            for id in v["punkte"] {
                st["sichtbar"].Push(id)
                st["gewaehlt"][id] := true
            }
        }
        if v.Has("zusatz") {
            for id in v["zusatz"]
                st["sichtbar"].Push(id)
        }
        if (v.Has("werte") and v["werte"] is Map) {
            for pid, je in v["werte"] {
                st["werte"][pid] := Map()
                for label, wert in je
                    st["werte"][pid][label] := wert
            }
        }
    }
    ; Dreiknopf links = vorangewaehlt: Werte des ersten Knopfs setzen.
    EegSetzeAbleitung(st, 1)
    EegSetzeVigilanz(st, 1)
    ; Medikamente: eine leere Zeile vorbereitet.
    st["medis"] := []
    loop r["medisVorbereitet"]
        st["medis"].Push(Map("name", "", "dosis", "", "frei", ""))
    ; Herd-/Entladungs-/Transienten-Zeilen: vorbereitet, inaktiv bis
    ; zum ersten Anfassen (Haekchen "aktiv" springt dann von selbst).
    st["herde"] := []
    loop r["herdeVorbereitet"]
        st["herde"].Push(EegNeueZeile("herd"))
    st["ent"] := []
    loop r["entladungenVorbereitet"]
        st["ent"].Push(EegNeueZeile("ent"))
    st["trans"] := [EegNeueZeile("trans")]
    sp := r["kisimSpruenge"]
    st["spr"] := [sp["nachAnamnese"], sp["nachBefund"], sp["nachBeurteilung"]]
    eegSt := st
    EegBaue()
}
EegNeueZeile(art) {
    r := EegRegeln()
    if (art = "herd") {
        v := r["herdVorwahl"]
        return Map("aktiv", false, "haeufigkeit", v["haeufigkeit"],
            "band", v["band"], "lok", v["lok"].Clone(),
            "seite", v["seite"], "ausbreitung", v["ausbreitung"])
    }
    if (art = "ent") {
        v := r["entVorwahl"]
        return Map("aktiv", false, "haeufigkeit", v["haeufigkeit"],
            "form", r["entFormen"][1], "lok", v["lok"].Clone(),
            "seite", v["seite"], "ausbreitung", v["ausbreitung"])
    }
    return Map("aktiv", false, "haeufigkeit", r["transHaeufigkeiten"][1],
        "lok", ["temporal", "", "", ""], "seite", "", "ausbreitung", "")
}
EegSetzeAbleitung(st, nr) {
    r := EegRegeln()
    k := r["ableitungKnoepfe"][nr]
    st["ablWahl"] := nr
    if !st["werte"].Has("abl_satz")
        st["werte"]["abl_satz"] := Map()
    for label, wert in k["werte"]
        st["werte"]["abl_satz"][label] := wert
    st["gewaehlt"]["abl_satz"] := true
    st["gewaehlt"]["art_50hz"] := k["artefakt50"] ? true : false
    if k["artefakt50"]
        EegZeigePunkt(st, "art_50hz")
}
EegSetzeVigilanz(st, nr) {
    r := EegRegeln()
    k := r["vigilanzKnoepfe"][nr]
    st["vigWahl"] := nr
    p := EegPunkt(st["m"], "vig_haupt")
    if (p = "")
        return
    for s in EegZerlege(p["text"]) {
        if (s["art"] = "text")
            continue
        if !st["werte"].Has("vig_haupt")
            st["werte"]["vig_haupt"] := Map()
        st["werte"]["vig_haupt"][s["label"]] := k["wert"]
        st["gewaehlt"]["vig_haupt"] := true
        return
    }
}
EegZeigePunkt(st, id) {
    for da in st["sichtbar"]
        if (da = id)
            return
    st["sichtbar"].Push(id)
}

EegZuGemacht() {
    global eegFenster
    eegFenster := ""
}
EegNeuAufbauen() {
    ; Lehre K1: erst zerstoeren, dann entkoppelt neu aufbauen.
    global eegFenster
    if (eegFenster != "") {
        try eegFenster.Destroy()
        eegFenster := ""
    }
    SetTimer(EegBaue, -25)
}

; ---- Das Fenster ---------------------------------------------------------
EegBaue() {
    global eegFenster, eegSt
    st := eegSt
    r := EegRegeln()
    if (eegFenster != "") {
        try eegFenster.Destroy()
        eegFenster := ""
    }
    g := Gui("+AlwaysOnTop +Resize", TX["eegTitel"] " - " st["vname"])
    g.SetFont("s10", "Segoe UI")
    g.OnEvent("Close", (*) => EegZuGemacht())
    g.Add("Text", "w960", TX["eegHinweis"])
    reiter := g.Add("Tab3", "w960", [TX["eegReiterIndAnam"], TX["eegBefund"], TX["eegBeurteilung"]])
    reiter.UseTab(1)
    EegBaueBereich(g, st, "indikation")
    EegBaueDazu(g, st, "indikation")
    g.SetFont("s9 bold")
    g.Add("Text", "xm y+10 w940", TX["eegMediTitel"])
    g.SetFont("s10 norm")
    EegBaueMedis(g, st)
    EegBaueBereich(g, st, "anamnese")
    EegBaueDazu(g, st, "anamnese")
    reiter.UseTab(2)
    EegBaueDreiknopf(g, st)
    EegBaueBereich(g, st, "befund")
    EegBaueZeilen(g, st)
    EegBaueDazu(g, st, "befund")
    reiter.UseTab(3)
    g.SetFont("s9 bold")
    g.Add("Text", "xm w940", TX["eegAutoTitel"])
    g.SetFont("s10 norm")
    for a in EegAutoSaetze(st)
        EegBaueAutoZeile(g, st, a)
    EegBaueBereich(g, st, "beurteilung")
    EegBaueDazu(g, st, "beurteilung")
    reiter.UseTab()
    g.Add("Text", "xm w960", TX["eegVorschau"])
    vorschau := g.Add("Edit", "xm w960 r8 Multi VScroll ReadOnly")
    vorschau.Value := EegVorschauText()
    kVor := g.Add("Button", "xm w220", TX["eegVorschauKnopf"])
    kVor.OnEvent("Click", (*) => (vorschau.Value := EegVorschauText()))
    g.Add("Text", "xm", TX["eegSpruenge"])
    sp1 := g.Add("Edit", "x+8 yp-4 w40 Number"), sp1.Value := st["spr"][1]
    sp2 := g.Add("Edit", "x+6 yp w40 Number"), sp2.Value := st["spr"][2]
    sp3 := g.Add("Edit", "x+6 yp w40 Number"), sp3.Value := st["spr"][3]
    sp1.OnEvent("Change", EegSprung.Bind(sp1, 1))
    sp2.OnEvent("Change", EegSprung.Bind(sp2, 2))
    sp3.OnEvent("Change", EegSprung.Bind(sp3, 3))
    kAlles := g.Add("Button", "x+24 yp w300", TX["eegAlles"])
    kAlles.OnEvent("Click", (*) => EegAllesEinfuegen(hinweis))
    kBefund := g.Add("Button", "x+10 w150", TX["eegNurBefund"])
    kBefund.OnEvent("Click", (*) => EegEinsEinfuegen("befund", hinweis))
    kBeurt := g.Add("Button", "x+10 w170", TX["eegNurBeurteilung"])
    kBeurt.OnEvent("Click", (*) => EegEinsEinfuegen("beurteilung", hinweis))
    kKopie := g.Add("Button", "xm y+6 w220", TX["eegKopieren"])
    kKopie.OnEvent("Click", (*) => EegKopieren(hinweis))
    hinweis := g.Add("Text", "x+12 yp+4 w700", "")
    g.Show("w1000")
    eegFenster := g
}
EegVorschauText() {
    global eegSt
    i := EegBereich(eegSt, "indikation")
    a := EegBereich(eegSt, "anamnese")
    b := EegBereich(eegSt, "befund")
    u := EegBereich(eegSt, "beurteilung")
    return TX["eegIndikation"] "`r`n" i[1] "`r`n`r`n" TX["eegAnamnese"] "`r`n" a[1]
        . "`r`n`r`n" TX["eegBefund"] "`r`n" b[1]
        . "`r`n`r`n" TX["eegBeurteilung"] "`r`n" u[1]
}
EegSprung(feld, nr, *) {
    global eegSt
    eegSt["spr"][nr] := (feld.Value != "") ? Number(feld.Value) : 0
}

; ---- Dreiknopf-Zeilen, Artefakte ----------------------------------------
EegBaueDreiknopf(g, st) {
    r := EegRegeln()
    g.SetFont("s9 bold")
    g.Add("Text", "xm w120 h22", TX["eegAbleitung"])
    g.SetFont("s10 norm")
    for i, k in r["ableitungKnoepfe"] {
        rad := g.Add("Radio", (i = 1 ? "x+8 yp-2 Group" : "x+8 yp"), k["name"])
        rad.Value := (st["ablWahl"] = i) ? 1 : 0
        rad.OnEvent("Click", EegAbleitungKlick.Bind(i))
    }
    g.SetFont("s9 bold")
    g.Add("Text", "xm y+8 w120 h22", TX["eegVigilanz"])
    g.SetFont("s10 norm")
    for i, k in r["vigilanzKnoepfe"] {
        rad := g.Add("Radio", (i = 1 ? "x+8 yp-2 Group" : "x+8 yp"), k["name"])
        rad.Value := (st["vigWahl"] = i) ? 1 : 0
        rad.OnEvent("Click", EegVigilanzKlick.Bind(i))
    }
    g.SetFont("s9 bold")
    g.Add("Text", "xm y+8 w120 h22", TX["eegArtefakte"])
    g.SetFont("s10 norm")
    namen := Map("art_augen", TX["eegArtAugen"], "art_muskel", TX["eegArtMuskel"],
        "art_bewegung", TX["eegArtBewegung"])
    for pid in r["artefaktKaestchen"] {
        kr := g.Add("Checkbox", "x+8 yp", namen[pid])
        kr.Value := (st["gewaehlt"].Has(pid) and st["gewaehlt"][pid]) ? 1 : 0
        kr.OnEvent("Click", EegArtefaktKlick.Bind(kr, pid))
    }
}
EegAbleitungKlick(nr, *) {
    global eegSt
    EegSetzeAbleitung(eegSt, nr)
    EegNeuAufbauen()
}
EegVigilanzKlick(nr, *) {
    global eegSt
    EegSetzeVigilanz(eegSt, nr)
    EegNeuAufbauen()
}
EegArtefaktKlick(kr, pid, *) {
    global eegSt
    eegSt["gewaehlt"][pid] := kr.Value ? true : false
    if kr.Value
        EegZeigePunkt(eegSt, pid)
}

; ---- Medikamenten-Zeilen -------------------------------------------------
EegBaueMedis(g, st) {
    r := EegRegeln()
    namen := []
    for n in r["antikonvulsiva"]
        namen.Push(n)
    namen.Push(r["mediFreitext"])
    for i, mz in st["medis"] {
        ddl := g.Add("DropDownList", "xm y+4 w200", namen)
        wahl := 0
        for nr, n in namen
            if (n = mz["name"])
                wahl := nr
        ddl.Value := wahl
        ddl.OnEvent("Change", EegMediName.Bind(ddl, i, namen))
        g.Add("Text", "x+8 yp+4 h22", TX["eegMediDosis"])
        dos := g.Add("Edit", "x+4 yp-4 w60")
        dos.Value := mz["dosis"]
        dos.OnEvent("Change", EegMediFeld.Bind(dos, i, "dosis"))
        g.Add("Text", "x+10 yp+4 h22", TX["eegMediFrei"])
        fr := g.Add("Edit", "x+4 yp-4 w220")
        fr.Value := mz["frei"]
        fr.OnEvent("Change", EegMediFeld.Bind(fr, i, "frei"))
    }
    kMehr := g.Add("Button", "xm y+6 w170", TX["eegMediMehr"])
    kMehr.OnEvent("Click", (*) => EegMediMehr())
}
EegMediName(ddl, i, namen, *) {
    global eegSt
    eegSt["medis"][i]["name"] := (ddl.Value >= 1) ? namen[ddl.Value] : ""
}
EegMediFeld(feld, i, was, *) {
    global eegSt
    eegSt["medis"][i][was] := feld.Value
}
EegMediMehr() {
    global eegSt
    if (eegSt["medis"].Length >= 6)
        return
    eegSt["medis"].Push(Map("name", "", "dosis", "", "frei", ""))
    EegNeuAufbauen()
}

; ---- Herd-, Transienten- und Entladungs-Zeilen ---------------------------
EegBaueZeilen(g, st) {
    r := EegRegeln()
    g.SetFont("s9 bold")
    g.Add("Text", "xm y+10 w940", TX["eegZeilenTitel"])
    g.SetFont("s10 norm")
    lok1 := [""]
    for reg in r["regionen"]
        lok1.Push(reg["id"])
    for s in r["spezialLok"]
        lok1.Push(s)
    lokN := [""]
    for reg in r["regionen"]
        lokN.Push(reg["id"])
    baender := []
    for b in r["baender"]
        baender.Push(b["wort"])
    for i, z in st["herde"]
        EegBaueZeile2(g, st, "herde", i, z, r["herdHaeufigkeiten"], baender, lok1, lokN, r)
    for i, z in st["trans"]
        EegBaueZeile2(g, st, "trans", i, z, r["transHaeufigkeiten"], "", lok1, lokN, r)
    for i, z in st["ent"]
        EegBaueZeile2(g, st, "ent", i, z, r["entHaeufigkeiten"], "", lok1, lokN, r)
    kH := g.Add("Button", "xm y+6 w150", TX["eegMehrHerd"])
    kH.OnEvent("Click", (*) => EegZeileMehr("herde", 4))
    kT := g.Add("Button", "x+8 w180", TX["eegMehrTrans"])
    kT.OnEvent("Click", (*) => EegZeileMehr("trans", 2))
    kE := g.Add("Button", "x+8 w180", TX["eegMehrEnt"])
    kE.OnEvent("Click", (*) => EegZeileMehr("ent", 3))
}
EegBaueZeile2(g, st, art, i, z, haeuf, baender, lok1, lokN, r) {
    titel := (art = "herde") ? TX["eegHerdWort"]
        : (art = "trans") ? TX["eegTransKurz"] : TX["eegEntWort"]
    kreuz := g.Add("Checkbox", "xm y+4 w110", titel " " i)
    kreuz.Value := z["aktiv"] ? 1 : 0
    kreuz.OnEvent("Click", EegZeileAktiv.Bind(kreuz, art, i))
    d1 := g.Add("DropDownList", "x+4 yp-4 w130", haeuf)
    EegDdlSetzen(d1, haeuf, z["haeufigkeit"])
    d1.OnEvent("Change", EegZeileWert.Bind(d1, kreuz, art, i, "haeufigkeit", haeuf))
    if (art = "herde") {
        d2 := g.Add("DropDownList", "x+4 yp w150", baender)
        EegDdlSetzen(d2, baender, EegBand(z["band"])["wort"])
        d2.OnEvent("Change", EegZeileBand.Bind(d2, kreuz, i, baender))
    }
    if (art = "ent") {
        d3 := g.Add("DropDownList", "x+4 yp w200", r["entFormen"])
        EegDdlSetzen(d3, r["entFormen"], z["form"])
        d3.OnEvent("Change", EegZeileWert.Bind(d3, kreuz, art, i, "form", r["entFormen"]))
    }
    loop 4 {
        n := A_Index
        liste := (n = 1) ? lok1 : lokN
        dl := g.Add("DropDownList", "x+4 yp w" (n = 1 ? 118 : 96), liste)
        EegDdlSetzen(dl, liste, z["lok"][n])
        dl.OnEvent("Change", EegZeileLok.Bind(dl, kreuz, art, i, n, liste))
    }
    ds := g.Add("DropDownList", "xm+114 y+2 w150", r["seiten"])
    EegDdlSetzen(ds, r["seiten"], z["seite"])
    ds.OnEvent("Change", EegZeileWert.Bind(ds, kreuz, art, i, "seite", r["seiten"]))
    da := g.Add("DropDownList", "x+4 yp w170", r["ausbreitungen"])
    EegDdlSetzen(da, r["ausbreitungen"], z["ausbreitung"])
    da.OnEvent("Change", EegZeileWert.Bind(da, kreuz, art, i, "ausbreitung", r["ausbreitungen"]))
}
EegDdlSetzen(ddl, liste, wert) {
    for i, o in liste
        if (o = wert)
            ddl.Value := i
}
EegZeileAktiv(kreuz, art, i, *) {
    global eegSt
    eegSt[art][i]["aktiv"] := kreuz.Value ? true : false
}
EegZeileWert(ddl, kreuz, art, i, feld, liste, *) {
    global eegSt
    eegSt[art][i][feld] := (ddl.Value >= 1) ? liste[ddl.Value] : ""
    eegSt[art][i]["aktiv"] := true
    kreuz.Value := 1
}
EegZeileBand(ddl, kreuz, i, baender, *) {
    global eegSt
    r := EegRegeln()
    if (ddl.Value >= 1)
        eegSt["herde"][i]["band"] := r["baender"][ddl.Value]["id"]
    eegSt["herde"][i]["aktiv"] := true
    kreuz.Value := 1
}
EegZeileLok(ddl, kreuz, art, i, n, liste, *) {
    global eegSt
    eegSt[art][i]["lok"][n] := (ddl.Value >= 1) ? liste[ddl.Value] : ""
    eegSt[art][i]["aktiv"] := true
    kreuz.Value := 1
}
EegZeileMehr(art, hoechstens) {
    global eegSt
    if (eegSt[art].Length >= hoechstens)
        return
    eegSt[art].Push(EegNeueZeile(art = "herde" ? "herd" : art = "ent" ? "ent" : "trans"))
    EegNeuAufbauen()
}

; ---- Auto-Beurteilungs-Zeilen (Stift ueberschreibt den Satz) ------------
EegBaueAutoZeile(g, st, a) {
    id := a["id"]
    soll := a["text"]
    st["autoSoll"][id] := soll
    if (st["bearbeite"] = id) {
        feld := g.Add("Edit", "xm y+4 w820 r2 Multi")
        feld.Value := st["abw"].Has(id) ? st["abw"][id] : soll
        ok := g.Add("Button", "x+6 yp w60", "OK")
        ok.OnEvent("Click", EegAutoAbwFertig.Bind(feld, id, false))
        weg := g.Add("Button", "y+2 xp w60", TX["eegZurueckVorgabe"])
        weg.OnEvent("Click", EegAutoAbwFertig.Bind(feld, id, true))
        return
    }
    if st["abw"].Has(id) {
        t := g.Add("Text", "xm y+4 w860", st["abw"][id])
        t.SetFont("bold cGray")
    } else {
        g.Add("Text", "xm y+4 w860", soll)
    }
    stift := g.Add("Button", "x+6 yp-4 w34", Chr(0x270E))
    stift.OnEvent("Click", EegStift.Bind(id))
}
EegAutoAbwFertig(feld, id, zurueck, *) {
    global eegSt
    if zurueck {
        if eegSt["abw"].Has(id)
            eegSt["abw"].Delete(id)
    } else {
        wert := Trim(feld.Value)
        soll := eegSt["autoSoll"].Has(id) ? Trim(eegSt["autoSoll"][id]) : ""
        if (wert = "" or wert = soll) {
            if eegSt["abw"].Has(id)
                eegSt["abw"].Delete(id)
        } else {
            eegSt["abw"][id] := wert
        }
    }
    eegSt["bearbeite"] := ""
    EegNeuAufbauen()
}

; ---- Punktlisten je Bereich (Renderer wie 16.0, bewaehrt) ---------------
EegBaueBereich(g, st, bereich) {
    m := st["m"]
    letzteKat := ""
    for id in st["sichtbar"] {
        p := EegPunkt(m, id)
        if (p = "")
            continue
        if (EegKategorieBereich(m, p["kategorie"]) != bereich)
            continue
        if (p["kategorie"] != letzteKat) {
            letzteKat := p["kategorie"]
            g.SetFont("s9 bold")
            g.Add("Text", "xm y+6 w940", EegKategorieName(m, letzteKat))
            g.SetFont("s10 norm")
        }
        EegBaueZeile(g, st, p)
    }
}
EegBaueDazu(g, st, bereich) {
    m := st["m"]
    uebrig := []
    uebrigIds := []
    for p in m["punkte"] {
        kb := EegKategorieBereich(m, p["kategorie"])
        if (kb != bereich)
            continue
        schonDa := false
        for id in st["sichtbar"]
            if (id = p["id"])
                schonDa := true
        if schonDa
            continue
        uebrig.Push(EegKategorieName(m, p["kategorie"]) ": " EegKurz(p["text"]))
        uebrigIds.Push(p["id"])
    }
    if uebrig.Length {
        g.SetFont("s9")
        g.Add("Text", "xm y+8", TX["eegDazu"])
        ddl := g.Add("DropDownList", "x+8 yp-4 w500", uebrig)
        ddl.OnEvent("Change", EegDazuGewaehlt.Bind(ddl, uebrigIds))
        g.SetFont("s10")
    }
}
EegDazuGewaehlt(ddl, ids, *) {
    global eegSt
    if (ddl.Value < 1)
        return
    id := ids[ddl.Value]
    eegSt["sichtbar"].Push(id)
    eegSt["gewaehlt"][id] := true
    EegNeuAufbauen()
}
EegBaueZeile(g, st, p) {
    pid := p["id"]
    kreuz := g.Add("Checkbox", "xm y+4", "")
    kreuz.Value := (st["gewaehlt"].Has(pid) and st["gewaehlt"][pid]) ? 1 : 0
    kreuz.OnEvent("Click", EegKreuz.Bind(kreuz, pid))
    if (st["bearbeite"] = pid) {
        feld := g.Add("Edit", "x+6 yp-2 w860 r2 Multi")
        feld.Value := st["abw"].Has(pid) ? st["abw"][pid] : EegAufgeloest(st, p)
        ok := g.Add("Button", "x+6 yp w60", "OK")
        ok.OnEvent("Click", EegAbwFertig.Bind(feld, pid, false))
        weg := g.Add("Button", "y+2 xp w60", TX["eegZurueckVorgabe"])
        weg.OnEvent("Click", EegAbwFertig.Bind(feld, pid, true))
        return
    }
    if st["abw"].Has(pid) {
        t := g.Add("Text", "x+6 yp+2 w860", st["abw"][pid])
        t.SetFont("bold cGray")
        stift := g.Add("Button", "x+6 yp-4 w34", Chr(0x270E))
    } else {
        x := 0
        erst := true
        for s in EegZerlege(p["text"]) {
            if (s["art"] = "text") {
                breite := StrLen(s["wert"]) * 7 + 4
                EegLege(g, &x, &erst, breite)
                g.Add("Text", (erst ? "x+6 yp+2" : "x+2 yp") " h22", s["wert"])
            } else if (s["art"] = "auswahl") {
                laengste := 4
                for o in s["optionen"]
                    laengste := Max(laengste, StrLen(o))
                breite := Min(laengste * 7 + 28, 320)
                EegLege(g, &x, &erst, breite)
                ddl := g.Add("DropDownList", (erst ? "x+6 yp-2" : "x+2 yp-2") " w" breite, s["optionen"])
                wert := EegWertVon(st, pid, s)
                wahl := 1
                for i, o in s["optionen"]
                    if (o = wert)
                        wahl := i
                ddl.Value := wahl
                ddl.OnEvent("Change", EegAuswahl.Bind(ddl, pid, s["label"], s["optionen"]))
                g.Add("Text", "x+0 yp+2 h22", "")
            } else {
                EegLege(g, &x, &erst, 76)
                ein := g.Add("Edit", (erst ? "x+6 yp-2" : "x+2 yp-2") " w70")
                ein.Value := EegWertVon(st, pid, s)
                ein.OnEvent("Change", EegFeld.Bind(ein, pid, s["label"]))
                g.Add("Text", "x+0 yp+2 h22", "")
            }
            if erst
                erst := false
            x += (s["art"] = "text") ? StrLen(s["wert"]) * 7 + 6
                : (s["art"] = "auswahl") ? 330 : 80
        }
        stift := g.Add("Button", "x+6 yp-4 w34", Chr(0x270E))
    }
    stift.OnEvent("Click", EegStift.Bind(pid))
}
EegLege(g, &x, &erst, breite) {
    if (!erst and x + breite > 900) {
        g.Add("Text", "xm+30 y+2 h4", "")
        erst := true
        x := 0
    }
}
EegKurz(text) {
    t := RegExReplace(String(text), "\{\{(Auswahl|Feld):([^:}=]+)[^}]*\}\}", "<$2>")
    return StrLen(t) > 70 ? SubStr(t, 1, 70) "..." : t
}
EegKategorieName(m, katId) {
    for k in m["kategorien"]
        if (k["id"] = katId)
            return k["name"]
    return katId
}
EegKategorieBereich(m, katId) {
    for k in m["kategorien"]
        if (k["id"] = katId)
            return k.Has("bereich") ? k["bereich"] : "befund"
    return "befund"
}

; ---- Rueckrufe (Top-Level, gebunden - Lehre K1) -------------------------
EegKreuz(kreuz, pid, *) {
    global eegSt
    eegSt["gewaehlt"][pid] := kreuz.Value ? true : false
}
EegAuswahl(ddl, pid, label, optionen, *) {
    global eegSt
    if !eegSt["werte"].Has(pid)
        eegSt["werte"][pid] := Map()
    eegSt["werte"][pid][label] := (ddl.Value >= 1) ? optionen[ddl.Value] : ""
    eegSt["gewaehlt"][pid] := true
}
EegFeld(ein, pid, label, *) {
    global eegSt
    if !eegSt["werte"].Has(pid)
        eegSt["werte"][pid] := Map()
    eegSt["werte"][pid][label] := ein.Value
    eegSt["gewaehlt"][pid] := true
}
EegStift(pid, *) {
    global eegSt
    eegSt["bearbeite"] := pid
    EegNeuAufbauen()
}
EegAbwFertig(feld, pid, zurueck, *) {
    global eegSt
    if zurueck {
        if eegSt["abw"].Has(pid)
            eegSt["abw"].Delete(pid)
    } else {
        wert := Trim(feld.Value)
        p := EegPunkt(eegSt["m"], pid)
        if (wert = "" or (p != "" and wert = Trim(EegAufgeloest(eegSt, p)))) {
            if eegSt["abw"].Has(pid)
                eegSt["abw"].Delete(pid)
        } else {
            eegSt["abw"][pid] := wert
            eegSt["gewaehlt"][pid] := true
        }
    }
    eegSt["bearbeite"] := ""
    EegNeuAufbauen()
}

; ---- Einfuegen und Kopieren ---------------------------------------------
EegSpringe(n) {
    global eegZiel
    WinActivate("ahk_id " eegZiel)
    Sleep 150
    loop n {
        SendEvent "^{Tab}"
        Sleep 150
    }
    Sleep 300
}
EegAllesEinfuegen(hinweis) {
    global eegSt, eegZiel
    i := EegBereich(eegSt, "indikation")
    a := EegBereich(eegSt, "anamnese")
    b := EegBereich(eegSt, "befund")
    u := EegBereich(eegSt, "beurteilung")
    hinweis.Value := TX["eegSpringeMeld"]
    WinActivate("ahk_id " eegZiel)
    Sleep 150
    FuegeEin(i[1], BermcRtfHuelle(i[2]), eegZiel, 0)
    EegSpringe(eegSt["spr"][1])
    FuegeEin(a[1], BermcRtfHuelle(a[2]), eegZiel, 0)
    EegSpringe(eegSt["spr"][2])
    FuegeEin(b[1], BermcRtfHuelle(b[2]), eegZiel, 0)
    EegSpringe(eegSt["spr"][3])
    FuegeEin(u[1], BermcRtfHuelle(u[2]), eegZiel, 0)
    hinweis.Value := TX["eegFertig"]
}
EegEinsEinfuegen(bereich, hinweis) {
    global eegSt, eegZiel
    t := EegBereich(eegSt, bereich)
    FuegeEin(t[1], BermcRtfHuelle(t[2]), eegZiel, 0)
    hinweis.Value := TX["eegEinsFertig"]
}
EegKopieren(hinweis) {
    A_Clipboard := EegVorschauText()
    hinweis.Value := TX["eegKopiert"]
}
