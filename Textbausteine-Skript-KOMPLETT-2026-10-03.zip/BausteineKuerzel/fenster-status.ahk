﻿; Datei: fenster-status.ahk
; Projekt: Textbausteine - Teil: Windows-Skript (AutoHotkey v2)
; Zweck: Das Status-Fenster direkt in KISIM (Etappe 11): ;;statuscts,
;        ;;statusstroke, ;;statusc7 ... (das Kuerzel jedes Status aus
;        der Status-Pflege der App) oeffnet dieses Fenster mit GENAU
;        diesem Status: die Punkte angekreuzt, Naeds eigene
;        Standardtexte als Normalbefund (normalAb), die Zusaetze
;        sichtbar aber nicht angewaehlt. Haekchen setzen, einen Befund
;        per Stift ueberschreiben (nur der veraenderte Wortbereich
;        wird fett dunkelgrau), bei Kraftpruefungen die Muskeln
;        waehlen - dann "Einfuegen": der fertige Status steht als EIN
;        Block an der Schreibmarke. Daten (statusMaster/
;        statusTeilmengen) kommen aus den abgeglichenen Einstellungen;
;        gepflegt wird NUR in der App, das Skript liest. Flache
;        Zustands-Kette mit SetTimer nach Destroy (Lehre K1).
;        GRUNDSATZ: nichts wird gespeichert, nichts verlaesst den
;        Rechner - der Status lebt nur in diesem Fenster.

global statusFenster := ""
global statusMuskelFenster := ""
global statusZiel := 0
global statusSt := ""

; ---- Zugriff auf Master und Teilmengen ----------------------------------
StatusMaster() {
    global einstellungen
    if (einstellungen.Has("statusMaster") and einstellungen["statusMaster"] is Map)
        return einstellungen["statusMaster"]
    return ""
}
StatusTeilmengen() {
    global einstellungen
    if (einstellungen.Has("statusTeilmengen") and einstellungen["statusTeilmengen"] is Array)
        return einstellungen["statusTeilmengen"]
    return []
}
StatusTeilmengeMitKuerzel(kuerzel) {
    for t in StatusTeilmengen() {
        if (t is Map and t.Has("kuerzel") and StrLower(String(t["kuerzel"])) = StrLower(kuerzel))
            return t
    }
    return ""
}
StatusUnit(m, uid) {
    for u in m["untersuchungen"] {
        if (u["id"] = uid)
            return u
    }
    return ""
}
StatusMitPunkt(t) {
    s := Trim(String(t))
    if (s = "")
        return s
    letzt := SubStr(s, -1)
    return (letzt = "." or letzt = "!" or letzt = "?") ? s : s "."
}

; ---- Normalbefund (Spiegel von status.js normalVon) ---------------------
; normalUeber (= normalAb der Teilmenge) ERSETZT den Normalbefund und
; erscheint darum nie fett. Bei Untersuchungen mit Einzelmerkmalen
; (Muskeln) wird er aus den GEWAEHLTEN Merkmalen gebaut.
StatusMerkmalAn(st, uid, mid) {
    return !(st["merkWahl"].Has(uid) and st["merkWahl"][uid].Has(mid)
        and st["merkWahl"][uid][mid])
}
StatusNormalVon(st, u) {
    uid := u["id"]
    if st["normalUeber"].Has(uid)
        return st["normalUeber"][uid]
    if !(u.Has("merkmale") and u["merkmale"] is Array)
        return u["normal"]
    teile := ""
    for mk in u["merkmale"] {
        if !StatusMerkmalAn(st, uid, mk["id"])
            continue
        teile .= (teile != "" ? ", " : "") mk["name"] " M5/M5"
    }
    return (teile = "") ? "xx." : teile "."
}
StatusBefundVon(st, u) {
    soll := StatusNormalVon(st, u)
    uid := u["id"]
    a := st["abw"].Has(uid) ? st["abw"][uid] : ""
    if (Trim(a) != "" and Trim(a) != Trim(String(soll)))
        return Map("text", StatusMitPunkt(a), "abweichend", true, "normal", soll)
    return Map("text", StatusMitPunkt(soll), "abweichend", false, "normal", soll)
}

; ---- Wort-Unterschied (Spiegel von status.js wortUnterschied) -----------
; Gemeinsamer Anfang und gemeinsames Ende (auf Wortgrenzen gerundet)
; bleiben normal; nur der veraenderte Bereich wird fett. Beginnt er
; mit einem Wert, kommt das Messwort davor mit (Naed 27.9.).
StatusWortUnterschied(normal, abw) {
    a := String(normal)
    b := String(abw)
    la := StrLen(a)
    lb := StrLen(b)
    vorn := 0
    while (vorn < la and vorn < lb
        and SubStr(a, vorn + 1, 1) == SubStr(b, vorn + 1, 1))
        vorn += 1
    hinten := 0
    while (hinten < la - vorn and hinten < lb - vorn
        and SubStr(a, la - hinten, 1) == SubStr(b, lb - hinten, 1))
        hinten += 1
    while (vorn > 0 and SubStr(b, vorn, 1) != " ")
        vorn -= 1
    while (hinten > 0 and SubStr(b, lb - hinten + 1, 1) != " ")
        hinten -= 1
    mitte := SubStr(b, vorn + 1, lb - hinten - vorn)
    if (mitte != "" and vorn > 0) {
        erstes := StrSplit(mitte, " ")[1]
        if RegExMatch(erstes, "[0-9/+\x{2212}-]") {
            davor := 0
            i := vorn - 1
            while (i >= 1) {
                if (SubStr(b, i, 1) = " ") {
                    davor := i
                    break
                }
                i -= 1
            }
            if RegExMatch(SubStr(b, davor + 1, 1), "[A-Za-z\x{C4}\x{D6}\x{DC}\x{E4}\x{F6}\x{FC}]") {
                vorn := davor
                mitte := SubStr(b, vorn + 1, lb - hinten - vorn)
            }
        }
    }
    if (mitte = "") {
        vorn := 0
        hinten := 0
        mitte := b
    }
    return Map("vor", SubStr(b, 1, vorn), "mitte", mitte,
        "nach", hinten > 0 ? SubStr(b, lb - hinten + 1) : "")
}

; ---- Fliesstext und RTF (Spiegel von status.js fliesstext) --------------
; Kategorien unterstrichen, jede auf neuer Zeile; "Name: Befund." -
; Ueberschriebenes fett in Dunkelgrau (#444444, Farbe 1 der Huelle).
StatusRtfHuelle(koerper) {
    kopf := "{\rtf1\ansi\ansicpg1252\deff0\deflang2055"
          . "{\fonttbl{\f0\fnil Arial;}}"
          . "{\colortbl;\red68\green68\blue68;}"
          . "\viewkind4\uc1 \pard\f0\fs20 "
    koerper := RegExReplace(koerper, "\\par $", "")
    return kopf koerper "}"
}
StatusText(st) {
    m := st["m"]
    text := ""
    rtf := ""
    for k in m["kategorien"] {
        zeileT := ""
        zeileR := ""
        for u in m["untersuchungen"] {
            if (u["kategorie"] != k["id"])
                continue
            uid := u["id"]
            if !(st["gewaehlt"].Has(uid) and st["gewaehlt"][uid])
                continue
            b := StatusBefundVon(st, u)
            zeileT .= (zeileT != "" ? " " : "") u["name"] ": " b["text"]
            if b["abweichend"] {
                d := StatusWortUnterschied(b["normal"], b["text"])
                satzR := BermcRtfText(u["name"]) ": " BermcRtfText(d["vor"])
                    . "\b\cf1 " BermcRtfText(d["mitte"]) "\cf0\b0 "
                    . BermcRtfText(d["nach"])
            } else {
                satzR := BermcRtfText(u["name"]) ": " BermcRtfText(b["text"])
            }
            zeileR .= (zeileR != "" ? " " : "") satzR
        }
        if (zeileT = "")
            continue
        text .= k["name"] ": " zeileT "`r`n"
        rtf .= "\ul " BermcRtfText(k["name"]) ":\ulnone  " zeileR "\par "
    }
    if (text != "")
        text := SubStr(text, 1, -2)
    return [text, rtf]
}

; ---- Oeffnen: Zustand aus der Teilmenge ---------------------------------
StatusOeffnen(ziel, kuerzel) {
    global statusZiel, statusSt
    m := StatusMaster()
    t := StatusTeilmengeMitKuerzel(kuerzel)
    if (m = "" or t = "") {
        Toast(TX["statusKeineDaten"], true)
        return
    }
    statusZiel := ziel
    st := Map()
    st["m"] := m
    st["name"] := t.Has("name") ? t["name"] : kuerzel
    st["gewaehlt"] := Map()
    st["sichtbar"] := []
    st["abw"] := Map()
    st["bearbeite"] := ""
    ; Punkte des Status: angekreuzt. Zusaetze: sichtbar, nicht
    ; angewaehlt (Spiegel der App-Aktivierung vom 2.10.).
    if (t.Has("punkte") and t["punkte"] is Array) {
        for uid in t["punkte"] {
            st["sichtbar"].Push(uid)
            st["gewaehlt"][uid] := true
        }
    }
    if (t.Has("zusatz") and t["zusatz"] is Array) {
        for uid in t["zusatz"] {
            schonDa := false
            for da in st["sichtbar"]
                if (da = uid)
                    schonDa := true
            if !schonDa
                st["sichtbar"].Push(uid)
        }
    }
    ; Abgeaenderte Standardtexte: SIND der Normalbefund (nie fett).
    st["normalUeber"] := Map()
    if (t.Has("normalAb") and t["normalAb"] is Map) {
        for uid, satz in t["normalAb"]
            st["normalUeber"][uid] := satz
    }
    ; Gespeicherte Muskel-Auswahl: merkmalAb = ABGEWAEHLTE Merkmale.
    st["merkWahl"] := Map()
    if (t.Has("merkmalAb") and t["merkmalAb"] is Map) {
        for uid, liste in t["merkmalAb"] {
            st["merkWahl"][uid] := Map()
            for mid in liste
                st["merkWahl"][uid][mid] := true
        }
    }
    ; Zusatz-Muskeln (gelbe Kandidaten der App): nur Hinweis-Stern.
    st["merkZusatz"] := Map()
    if (t.Has("merkmalZusatz") and t["merkmalZusatz"] is Map) {
        for uid, liste in t["merkmalZusatz"] {
            st["merkZusatz"][uid] := Map()
            for mid in liste
                st["merkZusatz"][uid][mid] := true
        }
    }
    statusSt := st
    StatusBaue()
}

StatusZuGemacht() {
    global statusFenster
    statusFenster := ""
}
StatusNeuAufbauen() {
    global statusFenster
    if (statusFenster != "") {
        try statusFenster.Destroy()
        statusFenster := ""
    }
    SetTimer(StatusBaue, -25)
}

; ---- Das Fenster: Reiter je Kategorie -----------------------------------
StatusBaue() {
    global statusFenster, statusSt
    st := statusSt
    m := st["m"]
    if (statusFenster != "") {
        try statusFenster.Destroy()
        statusFenster := ""
    }
    g := Gui("+AlwaysOnTop +Resize", TX["statusTitel"] " - " st["name"])
    g.SetFont("s10", "Segoe UI")
    g.OnEvent("Close", (*) => StatusZuGemacht())
    g.Add("Text", "w960", TX["statusHinweis"])
    ; Nur Kategorien mit sichtbaren Untersuchungen bekommen einen Reiter.
    kats := []
    for k in m["kategorien"] {
        if StatusKatHatSichtbare(st, k["id"])
            kats.Push(k)
    }
    namen := []
    for k in kats
        namen.Push(k["name"])
    if namen.Length {
        reiter := g.Add("Tab3", "w960", namen)
        for i, k in kats {
            reiter.UseTab(i)
            StatusBaueKategorie(g, st, k["id"])
        }
        reiter.UseTab()
    }
    ; "Dazu": der ganze Katalog, was noch nicht sichtbar ist.
    uebrig := []
    uebrigIds := []
    for u in m["untersuchungen"] {
        schonDa := false
        for da in st["sichtbar"]
            if (da = u["id"])
                schonDa := true
        if schonDa
            continue
        uebrig.Push(StatusKatName(m, u["kategorie"]) ": " u["name"])
        uebrigIds.Push(u["id"])
    }
    if uebrig.Length {
        g.SetFont("s9")
        g.Add("Text", "xm y+8", TX["statusDazu"])
        ddl := g.Add("DropDownList", "x+8 yp-4 w500", uebrig)
        ddl.OnEvent("Change", StatusDazuGewaehlt.Bind(ddl, uebrigIds))
        g.SetFont("s10")
    }
    g.Add("Text", "xm y+8 w960", TX["statusVorschau"])
    vorschau := g.Add("Edit", "xm w960 r8 Multi VScroll ReadOnly")
    vorschau.Value := StatusText(st)[1]
    kVor := g.Add("Button", "xm w220", TX["statusVorschauKnopf"])
    kVor.OnEvent("Click", (*) => (vorschau.Value := StatusText(statusSt)[1]))
    kEin := g.Add("Button", "x+12 yp w240", TX["statusEinfuegen"])
    kEin.OnEvent("Click", (*) => StatusEinfuegen(hinweis))
    kKopie := g.Add("Button", "x+12 w200", TX["statusKopieren"])
    kKopie.OnEvent("Click", (*) => StatusKopieren(hinweis))
    hinweis := g.Add("Text", "x+12 yp+4 w260", "")
    g.Show("w1000")
    statusFenster := g
}
StatusKatHatSichtbare(st, katId) {
    m := st["m"]
    for uid in st["sichtbar"] {
        u := StatusUnit(m, uid)
        if (u != "" and u["kategorie"] = katId)
            return true
    }
    return false
}
StatusKatName(m, katId) {
    for k in m["kategorien"]
        if (k["id"] = katId)
            return k["name"]
    return katId
}
StatusBaueKategorie(g, st, katId) {
    m := st["m"]
    ; Reihenfolge: die Master-Liste IST die Ordnung (wie in der App).
    for u in m["untersuchungen"] {
        if (u["kategorie"] != katId)
            continue
        sichtbar := false
        for da in st["sichtbar"]
            if (da = u["id"])
                sichtbar := true
        if !sichtbar
            continue
        StatusBaueZeile(g, st, u)
    }
}
StatusBaueZeile(g, st, u) {
    uid := u["id"]
    kreuz := g.Add("Checkbox", "xm y+4 w230", u["name"])
    kreuz.Value := (st["gewaehlt"].Has(uid) and st["gewaehlt"][uid]) ? 1 : 0
    kreuz.OnEvent("Click", StatusKreuz.Bind(kreuz, uid))
    if (st["bearbeite"] = uid) {
        feld := g.Add("Edit", "x+6 yp-2 w560 r2 Multi")
        feld.Value := st["abw"].Has(uid) ? st["abw"][uid] : StatusNormalVon(st, u)
        ok := g.Add("Button", "x+6 yp w60", "OK")
        ok.OnEvent("Click", StatusAbwFertig.Bind(feld, uid, false))
        weg := g.Add("Button", "y+2 xp w60", TX["statusZurueckVorgabe"])
        weg.OnEvent("Click", StatusAbwFertig.Bind(feld, uid, true))
        return
    }
    if st["abw"].Has(uid) {
        t := g.Add("Text", "x+6 yp+2 w560", st["abw"][uid])
        t.SetFont("bold cGray")
    } else {
        g.Add("Text", "x+6 yp+2 w560", StatusNormalVon(st, u))
    }
    stift := g.Add("Button", "x+6 yp-4 w34", Chr(0x270E))
    stift.OnEvent("Click", StatusStift.Bind(uid))
    if (u.Has("merkmale") and u["merkmale"] is Array) {
        an := 0
        for mk in u["merkmale"]
            if StatusMerkmalAn(st, uid, mk["id"])
                an += 1
        km := g.Add("Button", "x+6 yp w120",
            TX["statusMuskeln"] " " an "/" u["merkmale"].Length)
        km.OnEvent("Click", StatusMuskelnOeffnen.Bind(uid))
    }
    if (u.Has("hinweis") and String(u["hinweis"]) != "") {
        h := g.Add("Text", "xm+246 y+0 w560", u["hinweis"])
        h.SetFont("s8 cGray")
    }
}

; ---- Rueckrufe (Top-Level, gebunden - Lehre K1) -------------------------
StatusKreuz(kreuz, uid, *) {
    global statusSt
    statusSt["gewaehlt"][uid] := kreuz.Value ? true : false
}
StatusStift(uid, *) {
    global statusSt
    statusSt["bearbeite"] := uid
    StatusNeuAufbauen()
}
StatusAbwFertig(feld, uid, zurueck, *) {
    global statusSt
    if zurueck {
        if statusSt["abw"].Has(uid)
            statusSt["abw"].Delete(uid)
    } else {
        wert := Trim(feld.Value)
        u := StatusUnit(statusSt["m"], uid)
        soll := (u != "") ? Trim(String(StatusNormalVon(statusSt, u))) : ""
        if (wert = "" or wert = soll) {
            if statusSt["abw"].Has(uid)
                statusSt["abw"].Delete(uid)
        } else {
            statusSt["abw"][uid] := wert
            statusSt["gewaehlt"][uid] := true
        }
    }
    statusSt["bearbeite"] := ""
    StatusNeuAufbauen()
}
StatusDazuGewaehlt(ddl, ids, *) {
    global statusSt
    if (ddl.Value < 1)
        return
    uid := ids[ddl.Value]
    statusSt["sichtbar"].Push(uid)
    statusSt["gewaehlt"][uid] := true
    StatusNeuAufbauen()
}

; ---- Muskel-Unterfenster -------------------------------------------------
; Haekchen = Muskel ist im Befund; Zusatz-Muskeln der Teilmenge tragen
; einen Stern (Kandidaten, standardmaessig nicht angewaehlt - das
; regelt merkmalAb aus der App).
StatusMuskelnOeffnen(uid, *) {
    global statusMuskelFenster, statusSt
    if (statusMuskelFenster != "") {
        try statusMuskelFenster.Destroy()
        statusMuskelFenster := ""
    }
    u := StatusUnit(statusSt["m"], uid)
    if (u = "" or !u.Has("merkmale"))
        return
    g := Gui("+AlwaysOnTop", TX["statusMuskelTitel"] " - " u["name"])
    g.SetFont("s10", "Segoe UI")
    g.OnEvent("Close", (*) => StatusMuskelnZu())
    for i, mk in u["merkmale"] {
        stern := (statusSt["merkZusatz"].Has(uid)
            and statusSt["merkZusatz"][uid].Has(mk["id"])) ? Chr(0x2606) " " : ""
        lage := (i = 1) ? "xm y+6" : (i = 15) ? "x+40 ym+44" : "xm y+2"
        if (i > 15)
            lage := "xp y+2"
        kr := g.Add("Checkbox", lage " w220", stern mk["name"])
        kr.Value := StatusMerkmalAn(statusSt, uid, mk["id"]) ? 1 : 0
        kr.OnEvent("Click", StatusMuskelKreuz.Bind(kr, uid, mk["id"]))
    }
    kZu := g.Add("Button", "xm y+10 w160", TX["statusMuskelFertig"])
    kZu.OnEvent("Click", (*) => StatusMuskelnZu())
    g.Show()
    statusMuskelFenster := g
}
StatusMuskelKreuz(kr, uid, mid, *) {
    global statusSt
    if !statusSt["merkWahl"].Has(uid)
        statusSt["merkWahl"][uid] := Map()
    if kr.Value {
        if statusSt["merkWahl"][uid].Has(mid)
            statusSt["merkWahl"][uid].Delete(mid)
    } else {
        statusSt["merkWahl"][uid][mid] := true
    }
}
StatusMuskelnZu() {
    global statusMuskelFenster
    if (statusMuskelFenster != "") {
        try statusMuskelFenster.Destroy()
        statusMuskelFenster := ""
    }
    ; Die Muskel-Zaehler und Befundtexte frisch zeichnen.
    StatusNeuAufbauen()
}

; ---- Einfuegen und Kopieren ---------------------------------------------
StatusEinfuegen(hinweis) {
    global statusSt, statusZiel
    t := StatusText(statusSt)
    FuegeEin(t[1], StatusRtfHuelle(t[2]), statusZiel, 0)
    hinweis.Value := TX["statusFertig"]
}
StatusKopieren(hinweis) {
    global statusSt
    A_Clipboard := StatusText(statusSt)[1]
    hinweis.Value := TX["statusKopiert"]
}
